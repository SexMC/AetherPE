<?php

declare(strict_types=1);

namespace skyblock\commands\economy;

use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\Main;
use skyblock\sessions\Session;

class FishpointsCommand extends AetherCommand {
	protected function prepare() : void{
		$this->setDescription("View your fish points");
		$this->registerArgument(0, new RawStringArgument("player", true));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		if($sender instanceof Player){
			$username = $args["player"] ?? $sender->getName();

			$s = new Session($username);

			if($s->playerExists()){
				$sender->sendMessage(Main::PREFIX . "§c{$username}§7 has: §c" . number_format($s->getFishPoints()) . "§7 fish points");
			} else $sender->sendMessage(Main::PREFIX . "No played named §c{$username}§7 was found");
		}
	}
}