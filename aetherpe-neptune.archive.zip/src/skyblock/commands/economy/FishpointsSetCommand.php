<?php

declare(strict_types=1);

namespace skyblock\commands\economy;

use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\Main;
use skyblock\sessions\Session;

class FishpointsSetCommand extends AetherCommand {
	protected function prepare() : void{
		$this->setPermission("skyblock.command.fishpointset");
		$this->setDescription("Set fish points");

		$this->registerArgument(0, new RawStringArgument("player"));
		$this->registerArgument(1, new IntegerArgument("points"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
			$username = $args["player"];

			$s = new Session($username);

			if($s->playerExists()){
				$s->setFishPoints($args["points"]);


				$sender->sendMessage(Main::PREFIX . "Set §c{$username}'s§7 fish points to §c:" . number_format($args["points"]));
			} else $sender->sendMessage(Main::PREFIX . "No played named §c{$username}§7 was found");

	}
}