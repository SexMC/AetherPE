<?php

declare(strict_types=1);

namespace skyblock\commands\economy;

use pocketmine\command\CommandSender;
use skyblock\commands\AetherCommand;
use skyblock\communication\CommunicationLogicHandler;
use skyblock\communication\operations\economy\TopOperation;
use SOFe\AwaitGenerator\Await;

class LevelTopCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setDescription("View players with the highest farming levels");
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		Await::f2c(function() use($sender){
			$this->plugin->getCommunicationLogicHandler()->addOperation(new TopOperation(TopOperation::TYPE_FARMING_LEVEL, 0, 9, yield Await::RESOLVE));
			$data = yield Await::ONCE;

			if(isset($data["message"])){
				$sender->sendMessage("§7Top §c10 §7players with the highest farming levels!");
				$num = 1;
				foreach($data["message"] as $d){
					$value = $d["Value"];
					$player = $d["Player"];
					$sender->sendMessage("§c#$num §7{$player} - §c" . "Level $value");
					$num++;
				}
			}
		});
	}
}