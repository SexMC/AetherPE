<?php

declare(strict_types=1);

namespace skyblock\commands\staff;

use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use skyblock\commands\AetherCommand;
use skyblock\commands\arguments\SpecialSetArgument;
use skyblock\items\sets\SpecialSet;
use skyblock\Main;
use skyblock\utils\Utils;

class SpecialSetCommand extends AetherCommand{

	public function __construct(string $name, array $aliases = []){
		parent::__construct($name, $aliases);

		$this->setPermission("skyblock.command.specialset");
	}


	protected function prepare() : void{
		$this->registerArgument(0, new RawStringArgument("player"));

		$this->registerArgument(1, new SpecialSetArgument("specialset"));
		$this->setPermission("skyblock.command.specialset");
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		$p = Server::getInstance()->getPlayerExact($args["player"]);
		if($p === null){
			$sender->sendMessage(Main::PREFIX . "No player named §c{$args["player"]}§7 was found");
			return;
		}

		$set = $args["specialset"];

		foreach([SpecialSet::PIECE_LEGGINGS, SpecialSet::PIECE_CHESTPLATE, SpecialSet::PIECE_HELMET, SpecialSet::PIECE_BOOTS] as $piece){
			Utils::addItem($p, SpecialSet::getPiece($piece, $set, $p->getName()));
		}
		$sender->sendMessage(Main::PREFIX . "Gave {$p->getName()} {$set->getIdentifier()} special set");

	}
}