<?php

declare(strict_types=1);

namespace skyblock\commands\staff;

use CortexPE\Commando\args\IntegerArgument;
use pocketmine\command\CommandSender;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\commands\arguments\CustomEnchantArgument;
use skyblock\customenchants\CustomEnchant;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\items\ItemEditor;
use skyblock\Main;

class CustomEnchantCommand extends AetherCommand {


	protected function prepare() : void{
		$this->registerArgument(0, new CustomEnchantArgument("customenchant"));
		$this->registerArgument(1, new IntegerArgument("level"));
		$this->setPermission("skyblock.command.customenchant");
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if(!$player instanceof Player) return;

		$item = $player->getInventory()->getItemInHand();

		if($item->isNull()){
			$player->sendMessage(Main::PREFIX . "§cPlease hold a valid item");
			return;
		}

		$level = $args["level"];
		$ce = $args["customenchant"];

		ItemEditor::addCustomEnchantment($item, new CustomEnchantInstance($ce, $item, $level));
		$player->getInventory()->setItemInHand($item);
		$player->sendMessage(Main::PREFIX . "Added §c{$ce->getIdentifier()->getName()} {$level} §7to the item");
	}
}