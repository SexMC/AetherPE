<?php

declare(strict_types=1);

namespace skyblock\commands\staff;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\forms\commands\nbt\NBTItemForm;
use skyblock\items\lootbox\types\TestAetherCrate;
use skyblock\items\lootbox\animations\AetherCrateAnimation;

class NBTCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setPermission("skyblock.command.nbt");

	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player) {
			//(new AetherCrateAnimation(new TestAetherCrate(), $player))->send($player);

			$player->sendForm(new NBTItemForm($player->getInventory()->getItemInHand()));
		}
	}
}