<?php

declare(strict_types=1);

namespace skyblock\commands\staff;

use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\commands\arguments\DefinedStringArgument;
use skyblock\entity\minion\types\MinerMinion;
use skyblock\items\special\types\minion\MinerMinionSpawnEggItem;
use skyblock\items\special\types\minion\SlayerMinionSpawnEggItem;
use skyblock\Main;
use skyblock\utils\Utils;

class MinionCommand extends AetherCommand {
	protected function prepare() : void{
		$this->setPermission("skyblock.command.minion");
		$this->registerArgument(0, new RawStringArgument("player"));
		$this->registerArgument(1, new DefinedStringArgument(["miner" => "miner", "slayer" => "slayer"], "type"));
		$this->registerArgument(2, new IntegerArgument("level", true));
		$this->registerArgument(3, new IntegerArgument("speedTicks", true));
		$this->registerArgument(4, new IntegerArgument("fortune|looting", true));
		$this->registerArgument(5, new IntegerArgument("levelXP", true));
		$this->registerArgument(6, new IntegerArgument("durability", true));
		$this->registerArgument(7, new IntegerArgument("maxDurability", true));
		$this->registerArgument(8, new IntegerArgument("slots", true));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		$p = $sender->getServer()->getPlayerExact($args["player"]);

		if($p === null){
			$sender->sendMessage(Main::PREFIX . "{$args["player"]} is not online");
			return;
		}

		$type = $args["type"];

		switch($type){
			case "miner":
				$level = $args["level"] ?? 1;
				$xp = $args["xp"] ?? 0;
				$speedTicks = $args["speedTicks"] ?? 80;
				$fortune = $args["fortune|looting"] ?? 0;
				$dura = $args["durability"] ?? (VanillaItems::DIAMOND_PICKAXE())->getMaxDurability();
				$maxDura = $args["maxDurability"] ?? (VanillaItems::DIAMOND_PICKAXE())->getMaxDurability();
				$slots = $args["slots"] ?? 54;

				$item = MinerMinionSpawnEggItem::getItem($level, $xp, $speedTicks, $fortune, $dura, $maxDura, $slots);
				Utils::addItem($p, $item);
				$p->sendMessage(Main::PREFIX . "You have received a miner spawn egg");
				$sender->sendMessage(Main::PREFIX . "Gave §c{$p->getName()}§7 a miner spawn egg");
				break;
			case "slayer":
				$level = $args["level"] ?? 1;
				$xp = $args["xp"] ?? 0;
				$speedTicks = $args["speedTicks"] ?? 80;
				$fortune = $args["fortune|looting"] ?? 0;
				$dura = $args["durability"] ?? (VanillaItems::DIAMOND_SWORD())->getMaxDurability();
				$maxDura = $args["maxDurability"] ?? (VanillaItems::DIAMOND_SWORD())->getMaxDurability();
				$slots = $args["slots"] ?? 54;

				$item = SlayerMinionSpawnEggItem::getItem($level, $xp, $speedTicks, $fortune, $dura, $maxDura, $slots);
				Utils::addItem($p, $item);
				$p->sendMessage(Main::PREFIX . "You have received a miner spawn egg");
				$sender->sendMessage(Main::PREFIX . "Gave §c{$p->getName()}§7 a miner spawn egg");
				break;
		}
	}
}