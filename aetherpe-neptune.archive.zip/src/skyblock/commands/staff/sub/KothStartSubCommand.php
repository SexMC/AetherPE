<?php

declare(strict_types=1);

namespace skyblock\commands\staff\sub;

use pocketmine\command\CommandSender;
use skyblock\commands\AetherSubCommand;
use skyblock\commands\arguments\DefinedStringArgument;
use skyblock\Main;
use skyblock\misc\koth\Koth;
use skyblock\utils\Utils;

class KothStartSubCommand extends AetherSubCommand {
	protected function prepare() : void{
		$this->setPermission("skyblock.command.koth.start");
		$this->registerArgument(0, new DefinedStringArgument(["heroic" => Koth::MODE_HEROIC, "normal" => Koth::MODE_NORMAL], "type"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		if(Utils::isIslandServer()){
			$sender->sendMessage(Main::PREFIX . "You can only do this in the hub server");
			return;
		}

		$koth = Koth::getInstance();

		if($koth->isActive){
			$sender->sendMessage(Main::PREFIX . "KoTH is already active");
			return;
		}

		$koth->start($args["type"]);
	}
}