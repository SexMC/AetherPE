<?php

declare(strict_types=1);

namespace skyblock\commands\staff\sub;

use pocketmine\command\CommandSender;
use skyblock\commands\AetherSubCommand;
use skyblock\commands\arguments\DefinedStringArgument;
use skyblock\Main;
use skyblock\misc\koth\Koth;
use skyblock\utils\Utils;

class KothStopSubCommand extends AetherSubCommand {
	protected function prepare() : void{
		$this->setPermission("skyblock.command.koth.stop");
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		if(Utils::isIslandServer()){
			$sender->sendMessage(Main::PREFIX . "You can only do this in the hub server");
			return;
		}

		$koth = Koth::getInstance();

		if($koth->isActive){
			$koth->isActive = false;
			$koth->stop(false);
			Utils::announce(Main::PREFIX . "KoTH has been force stopped by {$sender->getName()}");
			return;
		}

		$sender->sendMessage(Main::PREFIX . "Koth is not active");
	}
}