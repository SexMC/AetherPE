<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\item\Armor;
use pocketmine\item\TieredTool;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\forms\commands\VanillaEnchantmentShopForm;
use skyblock\items\sets\SpecialSet;
use skyblock\Main;
use skyblock\traits\CooldownTrait;

class VanillaEnchantShopCommand extends AetherCommand{
	use CooldownTrait;

	protected function prepare() : void{
		$this->setDescription("Buy vanilla enchantments");

		$this->setAliases(["eshop", "veshop"]);
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		if($sender instanceof Player){

			$item = $sender->getInventory()->getItemInHand();
			if($item instanceof TieredTool || $item instanceof Armor){
				if($item instanceof Armor && $item->getNamedTag()->getString(SpecialSet::TAG_SPECIAL_SET, "") !== ""){
					$sender->sendMessage(Main::PREFIX . "§7This item cannot be enchanted");
					return;
				}
				$sender->sendForm(new VanillaEnchantmentShopForm($item));
				return;
			}
			
			$sender->sendMessage(Main::PREFIX . "§7This item cannot be enchanted");
		}
	}
}