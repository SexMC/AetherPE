<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\item\Armor;
use pocketmine\item\Durable;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\commands\basic\sub\FixAllSubCommand;
use skyblock\Main;
use skyblock\sessions\Session;
use skyblock\traits\CooldownTrait;

class FixCommand extends AetherCommand {

	public function canBeUsedInCombat() : bool{
		return true;
	}

	use CooldownTrait;

	protected function prepare() : void{
		$this->registerArgument(0, new RawStringArgument("hand", true));
		$this->registerSubCommand(new FixAllSubCommand("all"));
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			if($this->isOnCooldown($player)){
				$player->sendMessage(Main::PREFIX . "This command is on cooldown for " . ($this->getCooldown($player) . " second(s)"));
				return;
			}


			$item = $player->getInventory()->getItemInHand();
			if($item instanceof Durable){
				$this->setCooldown($player, 30);
				$item->setDamage(0);
				$player->getInventory()->setItemInHand($item);
				$player->sendMessage(Main::PREFIX . "Fixed the item you're holding");
			} else $player->sendMessage(Main::PREFIX . "This item cannot be fixed");
		}
	}
}