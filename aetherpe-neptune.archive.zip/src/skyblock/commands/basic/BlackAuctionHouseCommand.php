<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\commands\AetherCommand;
use skyblock\Main;
use skyblock\menus\commands\blackauctionhouse\BlackAuctionHouseMenu;
use skyblock\misc\blackauctionhouse\BlackAuctionHouse;
use skyblock\utils\Utils;

class BlackAuctionHouseCommand extends AetherCommand {
	protected function prepare() : void{
		$this->setDescription("Black Market");
		$this->registerArgument(0, new RawStringArgument("", true));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		$sender->sendMessage(Main::PREFIX . "This feature is locked down by fund");
		return; //todo


		if(($args[""] ?? null) === "start" && (Server::getInstance()->isOp($sender->getName()) || $sender instanceof ConsoleCommandSender)) {
			BlackAuctionHouse::getInstance()->start();

			return;
		}

		if(($args[""] ?? null) === "stop" && (Server::getInstance()->isOp($sender->getName()) || $sender instanceof ConsoleCommandSender)) {
			if(BlackAuctionHouse::getInstance()->isActive()){
				BlackAuctionHouse::getInstance()->stop();
			} else $sender->sendMessage(Main::PREFIX . "BAH is not active");

			return;
		}



		if($sender instanceof Player){

			if(Utils::isIslandServer()){
				$sender->sendMessage(Main::PREFIX . "You can only use this command at /spawn");
				return;
			}

			BlackAuctionHouse::getInstance()->getMenu()->send($sender);
		}
	}
}