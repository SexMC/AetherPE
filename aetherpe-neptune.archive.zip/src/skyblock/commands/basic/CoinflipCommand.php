<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\BaseSubCommand;
use pocketmine\color\Color;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\InkParticle;
use pocketmine\world\particle\RainSplashParticle;
use pocketmine\world\particle\RedstoneParticle;
use pocketmine\world\particle\SmokeParticle;
use skyblock\commands\AetherCommand;
use skyblock\commands\basic\sub\CoinflipCancelCommand;
use skyblock\forms\commands\coinflip\CoinflipForm;
use skyblock\forms\commands\coinflip\CoinflipSelectColorForm;
use skyblock\Main;
use skyblock\misc\coinflip\CoinflipHandler;
use skyblock\misc\warpspeed\IWarpSpeed;
use skyblock\misc\warpspeed\WarpSpeedHandler;
use SOFe\AwaitGenerator\Await;

class CoinflipCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setDescription("Gamble with money");

		$this->registerArgument(0, new IntegerArgument("amount", true));
		$this->registerSubCommand(new CoinflipCancelCommand("cancel"));
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){

			if(!WarpSpeedHandler::getInstance()->isUnlocked(IWarpSpeed::COINFLIP)){
				WarpSpeedHandler::getInstance()->sendMessage($player);
				return;
			}

			$amount = $args["amount"] ?? null;

			if($amount === null){
				Await::f2c(function() use($player){
					$player->sendForm(new CoinflipForm($player, yield CoinflipHandler::getInstance()->getAllCoinflips()));
				});

				return;
			}

			if($amount < 1000){
				$player->sendMessage(Main::PREFIX . "Amount must be greater than 1,000");
				return;
			}

			Await::f2c(function() use($player, $amount){
				$data = yield CoinflipHandler::getInstance()->getAllCoinflips();

				foreach($data as $k => $v){
					if(strtolower($v->getPlayer()) === strtolower($player->getName())){
						$player->sendMessage(Main::PREFIX . "You already have submitted a coin flip.");

						return;
					}
				}

				$player->sendForm(new CoinflipSelectColorForm(null, $amount));
			});
		}
	}
}
