<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\forms\commands\ItemForm;

class ItemCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setDescription("View your item in a form interface");
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			if($player->getInventory()->getItemInHand()->isNull()){
				$player->sendMessage("§cPlease hold an item");
				return;
			}

			$player->sendForm(new ItemForm($player->getInventory()->getItemInHand()));
		}
	}
}