<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\commands\AetherCommand;
use skyblock\communication\CommunicationLogicHandler;
use skyblock\communication\operations\mechanics\BragGetOperation;
use skyblock\communication\packets\types\mechanics\brag\AddBragPacket;
use skyblock\communication\packets\types\mechanics\brag\BragResponsePacket;
use skyblock\communication\packets\types\mechanics\brag\GetBragPacket;
use skyblock\Main;
use skyblock\menus\commands\BragMenu;
use SOFe\AwaitGenerator\Await;

class SeeBragCommand extends AetherCommand {
	protected function prepare() : void{
		$this->registerArgument(0, new RawStringArgument("player"));
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			Await::f2c(function() use($args, $player){
				CommunicationLogicHandler::getInstance()->sendPacket(new GetBragPacket(
					strtolower($args["player"]),
					yield Await::RESOLVE
				));

				/** @var BragResponsePacket $data */
				$data = yield Await::ONCE;
				if($data->player === "not_found"){
					$player->sendMessage(Main::PREFIX . "No brag found of a player named §c" . $args["player"]);
					return;
				}

				$menu = new BragMenu($data->player . "'s Inventory", $data->inventory, $data->armorInventory);
				$menu->send($player);
			});
		}
	}
}