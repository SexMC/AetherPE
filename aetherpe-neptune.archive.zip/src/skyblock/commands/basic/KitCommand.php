<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\commands\basic\sub\KitResetCommand;
use skyblock\Database;
use skyblock\forms\commands\KitsForm;
use skyblock\misc\kits\KitHandler;
use SOFe\AwaitGenerator\Await;

class KitCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setDescription("Claim your kits");
		$this->registerSubCommand(new KitResetCommand("reset"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		if($sender instanceof Player){


			Await::f2c(function() use($sender){
				$sender->sendForm(new KitsForm($sender, yield KitHandler::getInstance()->getCooldownData($sender->getName())));
			});
		}
	}
}