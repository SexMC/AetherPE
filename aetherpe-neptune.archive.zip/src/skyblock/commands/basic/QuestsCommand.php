<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\caches\playtime\PlayTimeCache;
use skyblock\commands\AetherCommand;
use skyblock\Main;
use skyblock\menus\quests\RegularQuestsMenu;
use skyblock\sessions\Session;
use skyblock\utils\TimeUtils;
use skyblock\utils\Utils;

class QuestsCommand extends AetherCommand{

	protected function prepare() : void{
		$this->registerArgument(0, new RawStringArgument("player", true));

		$this->setDescription("Player Quests");
		$this->setAliases(["quest"]);
		
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			(new RegularQuestsMenu($player, new Session($player)))->send($player);
		}
	}
}