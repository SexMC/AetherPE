<?php

declare(strict_types=1);

namespace skyblock\commands\basic\sub;

use CortexPE\Commando\args\IntegerArgument;
use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use skyblock\commands\AetherSubCommand;
use skyblock\Main;
use skyblock\player\AetherPlayer;
use skyblock\sessions\Session;
use skyblock\utils\Utils;

class FarmingSetSubCommand extends AetherSubCommand {
	protected function prepare() : void{
		$this->setPermission("skyblock.command.farmingset");
		$this->registerArgument(0, new RawStringArgument("player"));
		$this->registerArgument(1, new IntegerArgument("level"));
		$this->registerArgument(2, new IntegerArgument("xp"));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		$player = $args["player"];
		$level = $args["level"];
		$xp = $args["xp"];

		$s = new Session($player);
		if(!$s->playerExists()){
			$sender->sendMessage(Main::PREFIX . "§7No player named §c$player §7was found");
			return;
		}

		$s->setFarmingLevel($level);
		$s->setFarmingXP($xp);
		$sender->sendMessage(Main::PREFIX . "§c$player's§7 farming level has been set to §c" . number_format($level) . "§7 and xp has been set to §c" . number_format($xp));
		Utils::sendMessage($player, Main::PREFIX . "§7Your farming level and xp has been updated by §c" . $sender->getName());


		if(($p = $sender->getServer()->getPlayerExact($player)) instanceof AetherPlayer){
			assert($p instanceof AetherPlayer);

			$p->farmingBossBarUpdater->updateBossBar();
		}
	}
}