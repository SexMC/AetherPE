<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\items\ItemEditor;
use skyblock\items\itemmods\ItemMod;
use skyblock\items\itemmods\ItemModHandler;
use skyblock\Main;
use skyblock\utils\Utils;

class RemoveMaskCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setDescription("Remove masks from your items");
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			$item = $player->getInventory()->getItemInHand();
			$mask = ItemEditor::getMask($item);

			if($mask === null){
				$player->sendMessage(Main::PREFIX . "This item does not have any masks applied");
				return;
			}

			ItemEditor::setMask($item, null);
			$player->getInventory()->setItemInHand($item);
			Utils::addItem($player, $mask::getItem());

			$player->sendMessage(Main::PREFIX . "Removed the §c{$mask::getName()} §7mask");
		}
	}
}