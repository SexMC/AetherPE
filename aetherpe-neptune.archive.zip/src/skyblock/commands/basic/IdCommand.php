<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\Main;

class IdCommand extends AetherCommand {
	protected function prepare() : void{

	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			$item = $player->getInventory()->getItemInHand();

			$player->sendMessage(Main::PREFIX . $item->getId() . ":" . $item->getMeta());
		}
	}
}