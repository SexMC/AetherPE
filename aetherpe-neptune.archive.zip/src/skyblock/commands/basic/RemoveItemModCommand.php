<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\items\ItemEditor;
use skyblock\items\itemmods\ItemMod;
use skyblock\items\itemmods\ItemModHandler;
use skyblock\Main;
use skyblock\utils\Utils;

class RemoveItemModCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setDescription("Remove item mods from your items");
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			$item = $player->getInventory()->getItemInHand();
			$mods = ItemEditor::getItemMods($item);

			if(empty($mods)){
				$player->sendMessage(Main::PREFIX . "This item does not have any item mods applied");
				return;
			}

			$selected = $mods[array_rand($mods)];
			ItemEditor::removeItemMod($item, $selected);
			$player->getInventory()->setItemInHand($item);
			Utils::addItem($player, ItemMod::getItem($selected));

			$player->sendMessage(Main::PREFIX . "Removed the {$selected} item mod");
		}
	}
}