<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\commands\AetherCommand;
use skyblock\communication\CommunicationLogicHandler;
use skyblock\communication\operations\mechanics\BragGetOperation;
use skyblock\communication\operations\mechanics\SeeItemGetOperation;
use skyblock\communication\packets\types\mechanics\item\GetItemPacket;
use skyblock\communication\packets\types\mechanics\item\ItemResponsePacket;
use skyblock\Main;
use skyblock\menus\commands\BragMenu;
use skyblock\menus\commands\SeeItemMenu;
use SOFe\AwaitGenerator\Await;

class SeeItemCommand extends AetherCommand {

	protected function prepare() : void{
		$this->registerArgument(0, new RawStringArgument("player"));
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			Await::f2c(function() use($args, $player){
				CommunicationLogicHandler::getInstance()->sendPacket(new GetItemPacket(strtolower($args["player"]), yield Await::RESOLVE));
				/** @var ItemResponsePacket $data */
				$data = yield Await::ONCE;

				if($data->player === "not_found"){
					$player->sendMessage(Main::PREFIX . "No item found of a player named §c{$args["player"]}");
					return;
				}

				$menu = new SeeItemMenu($args["player"] . "'s Item", $data->item);
				$menu->send($player);

			});
		}
	}
}