<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\item\Armor;
use pocketmine\item\Tool;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ICustomEnchant;
use skyblock\items\ItemEditor;
use skyblock\Main;

class CeFixCommand extends AetherCommand {
	protected function prepare() : void{
		$this->setDescription("Fix glitched items");
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		if(!$sender instanceof Player) return;

		$item = $sender->getInventory()->getItemInHand();

		if($item instanceof Tool || $item instanceof Armor){
			/** @var CustomEnchantInstance[] $ce */
			$ce = ItemEditor::getCustomEnchantments($item);
			foreach($ce as $instance){
				if($instance->getCustomEnchant()->getRarity()->getTier() === ICustomEnchant::RARITY_HEROIC){
					if($instance->getCustomEnchant()->getChildEnchantmentId() === "") continue;

					unset($ce[$instance->getCustomEnchant()->getChildEnchantmentId()]);
					ItemEditor::removeCustomEnchant($item, $instance->getCustomEnchant()->getChildEnchantmentId());
				}
			}

			ItemEditor::updateCosmetics($item);
			$sender->getInventory()->setItemInHand($item);
			$sender->sendMessage(Main::PREFIX . "Updated the item in your hand");
		} else $sender->sendMessage(Main::PREFIX . "This item doesn't contain custom enchants");
	}
}