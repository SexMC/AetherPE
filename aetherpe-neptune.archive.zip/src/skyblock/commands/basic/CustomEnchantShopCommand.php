<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\forms\commands\ItemForm;
use skyblock\menus\commands\CollectMenu;
use skyblock\menus\commands\CustomEnchantShopMenu;
use skyblock\sessions\Session;

class CustomEnchantShopCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setDescription("Custom Enchants Shop");
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			(new CustomEnchantShopMenu($player))->send($player);
		}
	}
}