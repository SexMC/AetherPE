<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use CortexPE\Commando\args\RawStringArgument;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use skyblock\commands\AetherCommand;
use skyblock\Main;
use skyblock\misc\envoys\EnvoyHandler;
use skyblock\tasks\EnvoyStartTask;
use skyblock\utils\TimeUtils;
use skyblock\utils\Utils;
use pocketmine\utils\TextFormat as C;

class EnvoyCommand extends AetherCommand {
	protected function prepare() : void{
		$this->setDescription("View envoys");

		$this->registerArgument(0, new RawStringArgument("start", true));
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		if(Utils::isIslandServer()){
			$sender->sendMessage(Main::PREFIX . "You can only execute this command at spawn (/spawn)");
			return;
		}

		if(Server::getInstance()->isOp($sender->getName()) && isset($args["start"]) && $args["start"] === "start"){
			EnvoyHandler::getInstance()->startEnvoy();
		}

		$time = TimeUtils::secondsToTime(EnvoyStartTask::$timeLeft);
		$sender->sendMessage(EnvoyHandler::ENVOY_PREFIX . C::GRAY . "Envoy starts in §c" . $time["h"] . "h " . $time["m"] . "m " . $time["s"] . "s");
	}
}