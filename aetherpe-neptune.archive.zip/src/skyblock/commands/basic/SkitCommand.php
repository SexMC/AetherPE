<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\menus\commands\skit\SkitMenu;
use skyblock\misc\warpspeed\IWarpSpeed;
use skyblock\misc\warpspeed\WarpSpeedHandler;
use skyblock\sessions\Session;

class SkitCommand extends AetherCommand {
	protected function prepare() : void{
		$this->setDescription("Skits");
	}

	public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void{
		if(!$sender instanceof Player) return;

		if(!WarpSpeedHandler::getInstance()->isUnlocked(IWarpSpeed::SKIT)){
			WarpSpeedHandler::getInstance()->sendMessage($sender);
			return;
		}

		(new SkitMenu(new Session($sender)))->send($sender);
	}
}