<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\entity\TestEntity;
use skyblock\forms\commands\ItemForm;
use skyblock\menus\commands\CollectMenu;
use skyblock\sessions\Session;

class CollectCommand extends AetherCommand {

	protected function prepare() : void{
		$this->setDescription("Collect your items");
	}

	public function onRun(CommandSender $player, string $aliasUsed, array $args) : void{
		if($player instanceof Player){
			(new CollectMenu(new Session($player)))->send($player);
		}
	}
}