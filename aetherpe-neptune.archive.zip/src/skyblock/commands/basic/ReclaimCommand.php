<?php

declare(strict_types=1);

namespace skyblock\commands\basic;

use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use skyblock\commands\AetherCommand;
use skyblock\commands\basic\sub\ReclaimSetCommand;
use skyblock\Main;
use skyblock\sessions\Session;
use skyblock\utils\Utils;

class ReclaimCommand extends AetherCommand {
    protected function prepare() : void{
        $this->setDescription("View the real names of nicked players");
        $this->registerSubCommand(new ReclaimSetCommand("set"));
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args) : void {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Please use this command in-game");
            return;
        }

        $session = new Session($sender);
        if ($session->hasReclaimed()) {
            $sender->sendMessage(Main::PREFIX . "You have already used your reclaim this planet");
            return;
        }

        $rank = $session->getTopRank();
        foreach ($rank->getReclaim() as $item) {
            $session->addCollectItem($item);
        }

        $session->setReclaimed(true);
        Utils::announce(Main::PREFIX . "{$sender->getName()} has used there {$rank->getColour()}{$rank->getName()}§r§7 rank /reclaim");
        $sender->sendMessage(Main::PREFIX . "You have used your reclaim, do /collect to receive your items!");
    }
}