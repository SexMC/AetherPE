<?php

declare(strict_types=1);

namespace skyblock\blocks;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifierFlattened;
use pocketmine\block\BlockLegacyIds;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
use skyblock\entity\NetherMob;

class Water extends \pocketmine\block\Water {

    public function __construct() {
        parent::__construct(new BlockIdentifierFlattened(BlockLegacyIds::WATER, [BlockLegacyIds::STILL_WATER], 0), "Water", BlockBreakInfo::indestructible(500));
    }

    public function onEntityInside(Entity $entity) : bool{
        if ($entity instanceof NetherMob) {
            $ev = new EntityDamageByBlockEvent($this, $entity, EntityDamageEvent::CAUSE_DROWNING, 4);
            $entity->attack($ev);
        }

        return parent::onEntityInside($entity);
    }

}