<?php

declare(strict_types=1);

namespace skyblock\blocks;

use pocketmine\block\Block;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockIdentifier;
use pocketmine\block\BlockLegacyIds;
use pocketmine\block\BlockToolType;
use pocketmine\block\EnderChest;
use pocketmine\block\MonsterSpawner;
use pocketmine\data\bedrock\EntityLegacyIds;
use pocketmine\data\bedrock\LegacyEntityIdToStringIdMap;
use pocketmine\entity\Entity;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Location;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;
use pocketmine\item\SpawnEgg;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\world\BlockTransaction;
use pocketmine\world\Position;
use skyblock\caches\block\SpawnerSchedulerCache;
use skyblock\EntityHandler;
use skyblock\islands\Island;
use skyblock\islands\IslandInterface;
use skyblock\items\ItemEditor;
use skyblock\items\masks\MasksHandler;
use skyblock\items\masks\types\BunnyMask;
use skyblock\logs\LogHandler;
use skyblock\logs\types\SpawnerLog;
use skyblock\Main;
use skyblock\menus\SpawnerMenu;
use skyblock\sessions\Session;
use skyblock\tiles\MobSpawnerTile;
use skyblock\utils\EntityUtils;
use skyblock\utils\IslandUtils;
use skyblock\utils\Utils;

class MobSpawnerBlock extends MonsterSpawner {

	public const SPAWN_RANGE = 5;

	private array $sent = [];

	private bool $alreadyScheduled = false;

	public function __construct(){
		parent::__construct(new BlockIdentifier(BlockLegacyIds::MOB_SPAWNER, 0, null, MobSpawnerTile::class), "Monster Spawner", new BlockBreakInfo(5.0, BlockToolType::NONE));
	}

	public function onInteract(Item $item, int $face, Vector3 $clickVector, ?Player $player = null) : bool{
		if ($player === null) {
			return true;
		}

		if($item->getId() === ItemIds::SPAWN_EGG){
			$tile = $this->getPosition()->getWorld()->getTile($this->getPosition());
			if($tile instanceof MobSpawnerTile){
				$tile->setEntityId(LegacyEntityIdToStringIdMap::getInstance()->legacyToString($item->getMeta()));
			}
		}

		$island = IslandUtils::getIslandByWorld($this->getPosition()->getWorld());
		$session = new Session($player);
		$name = $session->getIslandName();
		$isCreative = $player->isCreative();

		if($isCreative){
			$this->sendMenu($player);
			return false;
		}

		if($name === null) {
			$player->sendMessage(Main::PREFIX . "You don't have permissions to access this spawner");
			return false;
		}

		if($island->getName() !== $name ){
			$player->sendMessage(Main::PREFIX . "You don't have permissions to access this spawner");
			return false;
		}

		if(!$island->isLeader($player) && !$island->hasPermission($player, IslandInterface::PERMISSION_BREAK_SPAWNERS)){
			$player->sendMessage(Main::PREFIX . "You don't have permissions to access this spawner");
			return false;
		}

		if(isset($this->sent[$player->getName()])){
			if(time() - $this->sent[$player->getName()] < 1){
				return true;
			}
		}

		$this->sendMenu($player);
		return false;
	}

	public function sendMenu(Player $player): bool {
		$tile = $this->getPosition()->getWorld()->getTile($this->getPosition());
		if($tile instanceof MobSpawnerTile){
			if(isset($this->sent[$player->getName()])){
				if(time() - $this->sent[$player->getName()] < 1){
					return true;
				}
			}

			$this->sent[$player->getName()] = time();
			(new SpawnerMenu($tile))->send($player);
			return true;
		}

		return false;
	}

	public function onBreak(Item $item, ?Player $player = null) : bool{
		$tile = $this->getPosition()->getWorld()->getTile($this->getPosition());
		if($tile instanceof MobSpawnerTile && !$tile->isClosed()){
			$player->sendMessage(Main::PREFIX . "You cannot break spawners, please interact with it to open the menu.");
			return false;
		}

		return parent::onBreak($item, $player);
	}

	public function place(BlockTransaction $tx, Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, ?Player $player = null) : bool{
		$chunkX = $blockReplace->getPosition()->getX() >> 4;
		$chunkZ = $blockReplace->getPosition()->getZ() >> 4;

		$chunk = $blockReplace->getPosition()->getWorld()->getChunk($chunkX, $chunkZ);

		if($chunk !== null){
			$found = false;
			$name = "";

			foreach($chunk->getTiles() as $tile){
				if($tile instanceof MobSpawnerTile){
					if($tile->getEntityId() === $item->getNamedTag()->getString("entityID", "")){
						$found = true;
						$name = $tile->getEntityId();
						break;
					}
				}
			}

			if($found){
				$player->sendMessage(Main::PREFIX . "There's already a " . EntityUtils::getEntityNameFromID($name) . " spawner in this chunk");
				return false;
			}
		}
		
		if($player !== null && $player->isSurvival()){
			$id = $item->getNamedTag()->getString("entityID", "");
			$name = (new Session($player))->getIslandName();
			if($id !== "" && $name !== null){
				$island = new Island($name);
				
				if(((bool) $island->getRedis()->get("island.{$island->getName()}.spawner.$id")) !== true){
					$player->sendMessage(Main::PREFIX . "§7You don't have this spawner unlocked §c(/is unlockables)!");
					return false;
				}
			}
		}

		$parent = parent::place($tx, $item, $blockReplace, $blockClicked, $face, $clickVector, $player);

		if($parent === true){
			$id = $item->getNamedTag()->getString("entityID", "");

			LogHandler::getInstance()->log(new SpawnerLog($player, EntityUtils::getEntityNameFromID($id), SpawnerLog::ACTION_PLACE, $blockReplace->getPosition()));
		}

		return $parent;
	}

	public function onScheduledUpdate() : void{
		if(!$this->alreadyScheduled){
			$this->alreadyScheduled = true;
			SpawnerSchedulerCache::getInstance()->schedule($this, 20 * mt_rand(5, 8));
		}

	}

	public function onUpdate(): void {
		$tile = $this->getPosition()->getWorld()->getTile($this->getPosition());
		if($tile instanceof MobSpawnerTile){

			$timer = 20 * mt_rand(30, 60);


			if(($p = $this->getPosition()->getWorld()->getNearestEntity($this->getPosition(), 25, Player::class)) instanceof Player) {
				if($mask = ItemEditor::getMask($p->getArmorInventory()->getHelmet())){
					if($mask::getName() === BunnyMask::getName()){
						$timer /= 2;
					}
				}

				$iterations = 0;
				$pos = $this->getEntitySpawnLocation();
				while($this->getPosition()->getWorld()->getBlock($pos)->getId() !== BlockLegacyIds::AIR){
					$pos = $this->getEntitySpawnLocation();

					if(++$iterations >= 20){
						break;
					}
				}

				EntityUtils::addEntity(new Location($pos->x, $pos->y, $pos->z, $this->position->getWorld(), 90, 90), $tile->getEntityId(), mt_rand(3, $tile->getStack() * 3 + 2));
			}

			SpawnerSchedulerCache::getInstance()->schedule($this, $timer);
		}
	}

	public function getEntitySpawnLocation(): Vector3 {
		$x = (int)($this->getPosition()->getX() + mt_rand() / mt_getrandmax() * self::SPAWN_RANGE);
		$y = (int)($this->getPosition()->getY() + mt_rand(0, 2));
		$z = (int)($this->getPosition()->getZ() + mt_rand() / mt_getrandmax() * self::SPAWN_RANGE);

		return new Vector3($x, $y, $z);
	}

	protected function getXpDropAmount() : int{
		return 0;
	}
}