<?php

declare(strict_types=1);

namespace skyblock\events\player;

use pocketmine\event\player\PlayerEvent;
use pocketmine\player\Player;

class PlayerFishEvent extends PlayerEvent {

	protected array $add = [];


	public function __construct(Player $player, private int $fishingXP, private array $rewards){
		$this->player = $player;
	}

	/**
	 * @return array
	 */
	public function getRewards() : array{
		return $this->rewards;
	}

	/**
	 * @return int
	 */
	public function getFishingXP() : int{
		return $this->fishingXP;
	}

	public function getFinalTotalFishingXP(): int {
		return array_sum($this->add) + $this->fishingXP;
	}

	public function addFishingXP(int $amount, string $reason): void {
		$this->add[$reason] = $amount;
	}
}