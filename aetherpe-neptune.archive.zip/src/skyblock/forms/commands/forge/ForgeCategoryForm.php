<?php

declare(strict_types=1);

namespace skyblock\forms\commands\forge;


use Closure;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use pocketmine\player\Player;
use skyblock\misc\forge\ForgeCategory;
use skyblock\misc\forge\ForgeElement;
use skyblock\sessions\Session;

class ForgeCategoryForm extends MenuForm {

	public function __construct(private ForgeCategory $category){
		parent::__construct(
			$this->category->title,
			"Select an element",
			array_merge(array_map(fn(ForgeElement $c) => $c->getFormButton(), $this->category->elements), [new MenuOption("§c<- Back>")]),
			Closure::fromCallable([$this, "handle"])
		);
	}

	public function handle(Player $player, int $btn): void {
		foreach($this->category->elements as $element){
			if($element->getFormButton()->getText() === $this->getOption($btn)->getText()){
				$player->sendForm(new ForgeElementForm(new Session($player), $element));
				return;
			}
		}

		$player->sendForm(new ForgeForm());
	}
}