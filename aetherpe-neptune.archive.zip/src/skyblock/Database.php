<?php

declare(strict_types=1);

namespace skyblock;

use pocketmine\timings\Timings;
use pocketmine\timings\TimingsHandler;
use poggit\libasynql\DataConnector;
use poggit\libasynql\libasynql;
use RedisClient\Client\Version\RedisClient6x0;
use RedisClient\ClientFactory;
use skyblock\utils\Queries;
use skyblock\utils\Utils;
use SOFe\AwaitGenerator\Await;

class Database {

	/**
	 * @var RedisClient6x0
	 */
	private RedisClient6x0 $redis;

	private static Database $instance;

	private DataConnector $libasynql;

	private DataConnector $logs;

	public function __construct(){
		self::$instance = $this;

		$this->redis = ClientFactory::create([
			'server' => '135.148.150.31:6379', // or 'unix:///tmp/redis.sock'
			'timeout' => 2,
			'version' => '6.0',
			'password' => 'çKç{àièngOfTurb7kEMY31_?Su&0cKs-',
		]);

		$this->libasynql = libasynql::create(Main::getInstance(), Main::getInstance()->getConfig()->get("libasynql"), ["mysql" => ["mysql/kits.sql", "mysql/worlds.sql", "mysql/safezones.sql", "mysql/warps.sql"]]);

		$this->libasynql->executeGeneric(Queries::KITS_TABLE_CREATE);
		$this->libasynql->executeGeneric(Queries::WORLDS_TABLE_CREATE);
		$this->libasynql->executeGeneric(Queries::SAFEZONES_TABLE_CREATE);
		$this->libasynql->executeGeneric(Queries::WARP_TABLE_CREATE);

		$this->logs = libasynql::create(Main::getInstance(), Main::getInstance()->getConfig()->get("logs"), ["mysql" => ["mysql/logs.sql"]]);
	}

	/**
	 * @return DataConnector
	 */
	public function getLogs() : DataConnector{
		return $this->logs;
	}

	/**
	 * @return Database
	 */
	public static function getInstance() : Database{
		return self::$instance;
	}

	/**
	 * @return RedisClient6x0
	 */
	public function getRedis(): RedisClient6x0{
		return $this->redis;
	}

	public function redisGet(string $get) {
		Timings::$tickTileEntity->startTiming();
		$start = microtime(true);
		//echo "Before redis GET: $get" . "\n";
		$resp = $this->redis->get($get);
		$end = microtime(true);
		Timings::$tickTileEntity->stopTiming();

		//echo "Took: " . ($end - $start) . "s for redis GET query: $get" . "\n";

		return $resp;
	}

	public function redisSet(string $get, $value) {
		Timings::$tickTileEntity->startTiming();
		$start = microtime(true);
		//echo "Before redis SET: $get";
		$resp = $this->redis->set($get, $value);
		$end = microtime(true);
		Timings::$tickTileEntity->stopTiming();

		//echo "Took: " . ($end - $start) . "s for redis SET query: $get" . "\n";

		return $resp;
	}

	/**
	 * @return DataConnector
	 */
	public function getLibasynql() : DataConnector{
		return $this->libasynql;
	}

}