<?php

declare(strict_types=1);

namespace skyblock\entity\boss;

use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Living;
use pocketmine\entity\projectile\Arrow;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector2;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\player\Player;
use skyblock\entity\ai\MovingEntity;
use skyblock\entity\misc\Fireball;
use skyblock\player\AetherPlayer;

class WitheredBlazeBoss extends MovingEntity  {

	protected function initEntity(CompoundTag $nbt) : void{
		parent::initEntity($nbt);
		$this->getNetworkProperties()->setInt(EntityMetadataProperties::VARIANT, 1);
		$this->setCanSaveWithChunk(false);
	}

	protected function getInitialSizeInfo() : EntitySizeInfo{
		return new EntitySizeInfo(1.8, 0.5);
	}

	public static function getNetworkTypeId() : string{
		return EntityIds::BLAZE;
	}

	public function getName() : string{
		return "§r§l§8With§7ered §6Bla§eze";
	}

	public function getNameTag() : string{
		$format = number_format($this->getHealth(), 2);
		return "§r§l§8With§7ered §6Bla§eze\n§r§c{$format} §l❤";
	}

	public function setHealth(float $amount) : void{
		parent::setHealth($amount);
		$this->networkPropertiesDirty = true;
	}
}