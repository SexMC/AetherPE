<?php

declare(strict_types=1);

namespace skyblock\entity;

use czechpmdevs\buildertools\utils\BlockFacingHelper;
use pocketmine\block\BlockFactory;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Living;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\StopSoundPacket;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataCollection;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;

class TestEntity extends Living {

	protected function initEntity(CompoundTag $nbt) : void{
		parent::initEntity($nbt);
	}

	protected function syncNetworkData(EntityMetadataCollection $properties) : void{
		parent::syncNetworkData($properties);
	}

	public function isSilent() : bool{
		return true;
	}


	protected function getInitialSizeInfo() : EntitySizeInfo{
		return new EntitySizeInfo(2, 2);
	}

	public static function getNetworkTypeId() : string{
		return "minecraft:zombie";
	}

	public function getName() : string{
		return "blaze";
	}
}