<?php

declare(strict_types=1);

namespace skyblock\entity;

abstract class NetherMob extends Mob {

}