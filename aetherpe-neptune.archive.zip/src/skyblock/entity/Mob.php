<?php

declare(strict_types=1);

namespace skyblock\entity;

use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use skyblock\utils\Utils;

abstract class Mob extends Living {

	private int $stackSize = 1;

	private bool $shouldIgnore = false;

	protected function initEntity(CompoundTag $nbt) : void{
		parent::initEntity($nbt);

		$this->setStackSize($nbt->getInt("stack", 1));
	}

	public function getDrops() : array{
		$arr = $this->getAllDrops();

		foreach($arr as $k => $v){
			if($v->isNull()){
				unset($arr[$k]);
			}

			$v->setCustomName("§r§l§f" . $v->getVanillaName());
			$v->setLore(["§r§l§fSELLABLE ITEM", "§r§7(Use /sell to sell this item)"]);
			$v->getNamedTag()->setByte("md", 1); //md = mob drop
		}

		return $arr;
	}

	public function attack(EntityDamageEvent $source) : void{
		if($this->attackTime > 0) {
			$source->cancel();
			return;
		}

		if($source->getCause() === EntityDamageEvent::CAUSE_VOID){
			$this->flagForDespawn();
		}

		parent::attack($source);
	}


	public function kill() : void{
		if($this->getStackSize() > 1){
			$this->decreaseStackSize(1);

			$ev = new EntityDeathEvent($this, $this->getDrops(), $this->getXpDropAmount());
			$ev->call();


			return;
		}

		parent::kill();
	}

	public function checkStack(): void {
		$entities = $this->getWorld()->getChunkEntities($this->getLocation()->x >> 4, $this->getLocation()->z >> 4);

		foreach ($entities as $entity) {
			/** @var Mob $entity */
			if ($entity instanceof Mob && $entity::getNetworkTypeId() === static::getNetworkTypeId() && $entity->getId() !== $this->getId()) {
				if($entity->isClosed() || $entity->isFlaggedForDespawn() || $entity->shouldIgnore()) continue;

				$this->increaseStackSize($entity->getStackSize());

				$entity->setShouldIgnore(true);
				$entity->flagForDespawn();
				break;
			}
		}
	}

	protected function move(float $dx, float $dy, float $dz) : void{
		parent::move($dx, $dy, $dz);

		$this->checkStack();
	}

	protected function setPosition(Vector3 $pos) : bool{
		$return = parent::setPosition($pos);
		$this->checkStack();

		return $return;
	}

	public function saveNBT() : CompoundTag{
		$nbt = parent::saveNBT();
		$nbt->setInt("stack", $this->stackSize);

		return $nbt;
	}

	public function updateNameTag(): void {
		$this->setNameTag(TextFormat::YELLOW . TextFormat::BOLD . $this->getName() . " x" . $this->getStackSize());
	}


	public function getStackSize() : int{
		return $this->stackSize;
	}

	public function setStackSize(int $stackSize) : void{
		$this->stackSize = $stackSize;
		$this->updateNameTag();
	}

	public function decreaseStackSize(int $stackSize) : void{
		$this->stackSize -= $stackSize;
		$this->updateNameTag();
	}

	public function increaseStackSize(int $stackSize) : void{
		$this->stackSize += $stackSize;
		$this->updateNameTag();
	}

	public function shouldIgnore() : bool{
		return $this->shouldIgnore;
	}

	public function setShouldIgnore(bool $shouldIgnore) : void{
		$this->shouldIgnore = $shouldIgnore;
	}

	/**
	 * @return Item[]
	 */
	public function getAllDrops(): array {
		return [];
	}
}