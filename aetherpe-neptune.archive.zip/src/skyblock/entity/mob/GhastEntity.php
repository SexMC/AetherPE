<?php

declare(strict_types=1);

namespace skyblock\entity\mob;

use pocketmine\block\BlockLegacyIds;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use skyblock\entity\Mob;
use skyblock\entity\NetherMob;

class GhastEntity extends NetherMob {
    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(4, 4);
    }

    public static function getNetworkTypeId(): string {
        return EntityIds::GHAST;
    }


    public function getName(): string {
        return "Ghast";
    }

    public function getXpDropAmount(): int {
        return 5;
    }

    public function attack(EntityDamageEvent $source): void {
        $immune = [EntityDamageEvent::CAUSE_DROWNING, EntityDamageEvent::CAUSE_LAVA, EntityDamageEvent::CAUSE_FIRE, EntityDamageEvent::CAUSE_FIRE_TICK];

        if (in_array($source->getCause(), $immune)) {
            $source->cancel();

            return;
        }

        if ($source instanceof EntityDamageByBlockEvent) {
            if ($source->getDamager()->getId() === BlockLegacyIds::CACTUS) {
                $source->setBaseDamage($source->getBaseDamage() * 4);
            }
        }

        parent::attack($source);
    }

    public function getAllDrops(): array {
        return [
            VanillaItems::GHAST_TEAR()->setCount(mt_rand(1, 2)),
        ];
    }
}