<?php

declare(strict_types=1);

namespace skyblock\entity\mob;

use pocketmine\block\VanillaBlocks;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use skyblock\entity\Mob;

class GuardianEntity extends Mob{
	protected function getInitialSizeInfo() : EntitySizeInfo{
		return new EntitySizeInfo(0.85, 0.85);
	}

	public static function getNetworkTypeId() : string{
		return EntityIds::GUARDIAN;
	}


	public function getName() : string{
		return "Guardian";
	}

	public function getAllDrops() : array{
		return [
			VanillaBlocks::EMERALD()->asItem()->setCount(mt_rand(1, 2)),
		];
	}

	public function getXpDropAmount() : int{
		return 9;
	}
}