<?php

declare(strict_types=1);

namespace skyblock\entity\mob;

use pocketmine\entity\EntitySizeInfo;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use skyblock\entity\Mob;

class PhantomEntity extends Mob{
	protected function getInitialSizeInfo() : EntitySizeInfo{
		return new EntitySizeInfo(0.5, 0.9);
	}

	public static function getNetworkTypeId() : string{
		return EntityIds::PHANTOM;
	}


	public function getName() : string{
		return "Phantom";
	}

	public function getAllDrops() : array{
		return [
			ItemFactory::getInstance()->get(ItemIds::PHANTOM_MEMBRANE)->setCount(mt_rand(1, 2)),
		];
	}

	public function getXpDropAmount() : int{
		return 6;
	}
}