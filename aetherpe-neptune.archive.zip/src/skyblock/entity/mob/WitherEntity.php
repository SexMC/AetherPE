<?php

declare(strict_types=1);

namespace skyblock\entity\mob;

use pocketmine\entity\EntitySizeInfo;
use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use skyblock\entity\Mob;
use skyblock\entity\NetherMob;

class WitherEntity extends NetherMob {
    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(3, 1);
    }

    public static function getNetworkTypeId(): string {
        return EntityIds::WITHER;
    }


    public function getName(): string {
        return "Wither";
    }

    public function getAllDrops(): array {
        return [
            VanillaItems::NETHER_STAR()->setCount(mt_rand(1, 2)),
        ];
    }

    public function getXpDropAmount(): int {
        return 9;
    }
}