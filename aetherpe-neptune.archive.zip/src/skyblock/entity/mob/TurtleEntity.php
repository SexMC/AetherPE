<?php

declare(strict_types=1);

namespace skyblock\entity\mob;

use pocketmine\block\VanillaBlocks;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use skyblock\entity\Mob;

class TurtleEntity extends Mob{
	protected function getInitialSizeInfo() : EntitySizeInfo{
		return new EntitySizeInfo(0.4, 1.2);
	}

	public static function getNetworkTypeId() : string{
		return EntityIds::TURTLE;
	}


	public function getName() : string{
		return "Turtle";
	}

	public function getAllDrops() : array{
		return [
			VanillaItems::SCUTE()->setCount(mt_rand(1, 2)),
		];
	}

	public function getXpDropAmount() : int{
		return 9;
	}
}