<?php

declare(strict_types=1);

namespace skyblock\entity\mob;

use pocketmine\entity\EntitySizeInfo;
use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use skyblock\entity\Mob;

class ZombieEntity extends Mob{
	protected function getInitialSizeInfo() : EntitySizeInfo{
		return new EntitySizeInfo(1.8, 0.6);
	}

	public static function getNetworkTypeId() : string{
		return EntityIds::ZOMBIE;
	}


	public function getName() : string{
		return "Zombie";
	}

	public function getAllDrops() : array{
		return [
			VanillaItems::ROTTEN_FLESH()->setCount(mt_rand(1, 2)),
		];
	}

	public function getXpDropAmount() : int{
		return 5;
	}
}