<?php

declare(strict_types=1);

namespace skyblock\entity\mob;

use pocketmine\entity\EntitySizeInfo;
use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use skyblock\entity\Mob;

class SkeletonEntity extends Mob{
	protected function getInitialSizeInfo() : EntitySizeInfo{
		return new EntitySizeInfo(1.9, 0.6);
	}

	public static function getNetworkTypeId() : string{
		return EntityIds::SKELETON;
	}


	public function getName() : string{
		return "Skeleton";
	}

	public function getAllDrops() : array{
		return [
			VanillaItems::BONE()->setCount(mt_rand(1, 2)),
			VanillaItems::ARROW()->setCount(mt_rand(0, 1)),
		];
	}

	public function getXpDropAmount() : int{
		return 5;
	}
}