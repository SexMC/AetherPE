<?php

declare(strict_types=1);

namespace skyblock\entity\ai;

use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Human;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\ActorEventPacket;
use pocketmine\network\mcpe\protocol\types\ActorEvent;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;
use pocketmine\Server;

abstract class MovingEntity extends Living {

	const ATTACK_COOLDOWN = 20;
	const SEARCH_COOLDOWN = 5;
	const KNOCKBACK_TICKS = 6;

	/** @var int */
	public int $attackCooldown = 0;
	/** @var int */
	public int $knockBackTicks = 0;

	/** @var int */
	public float $damage = 1;
	/** @var float */
	public float $speed = 1.15;


	/** @var int */
	protected int $searchTargetCooldown = 0;
	/** @var null|Player */
	protected ?Entity $target = null;

	public function attackEntity(Entity $entity): void {
		$this->attackCooldown = self::ATTACK_COOLDOWN;
		$entity->attack(new EntityDamageByEntityEvent($this, $entity, EntityDamageByEntityEvent::CAUSE_ENTITY_ATTACK, $this->damage));
		$this->doArmSwingAnimation();
	}

	public function onUpdate(int $currentTick): bool {
		$this->attackCooldown--;
		$this->searchTargetCooldown--;
		$this->knockBackTicks--;

		if(($this->target === null || $this->target->getPosition()->distance($this->getPosition()) >= 15) && $this->searchTargetCooldown < 1) {
			$this->searchTargetCooldown = self::SEARCH_COOLDOWN;
			$entity = $this->getWorld()->getNearestEntity($this->getPosition(), 150, Player::class);
			if($entity !== null) {
				$this->target = $entity;
			}
			return parent::onUpdate($currentTick);
		}

		if($this->target === null) {
			return parent::onUpdate($currentTick);
		}

		if(!$this->target->isOnline()){
			$this->target = null;
			return parent::onUpdate($currentTick);
		}

		if($this->isInReach($this->target) && $this->isAlive()) {
			$this->attackEntity($this->target);
		}

		if($this->target->isSurvival() && $this->target->getAllowFlight()){
			$this->target->setAllowFlight(false);
			$this->target->setFlying(false);
		}

		if($this->knockBackTicks > 0) {
			return parent::onUpdate($currentTick);
		}

		$x = $this->target->getPosition()->x - $this->getPosition()->x;
		$z = $this->target->getPosition()->z - $this->getPosition()->z;
		if ($x ** 2 + $z ** 2 < 0.7) {
			$this->motion->x = 0;
			$this->motion->z = 0;
		} else {
			$diff = abs($x) + abs($z);
			$this->motion->x = $this->speed * 0.15 * ($x / $diff);
			$this->motion->z = $this->speed * 0.15 * ($z / $diff);
		}
		$this->move($this->motion->x, $this->motion->y, $this->motion->z);
		$this->lookAt($this->target->getLocation());

		return parent::onUpdate($currentTick);
	}

	public function attack(EntityDamageEvent $source): void {
		$this->knockBackTicks = self::KNOCKBACK_TICKS;

		if($this->location->world->isLoaded()){
			parent::attack($source);
		}
	}

	public function isInReach(Entity $entity): bool {
		return $entity->getPosition()->distance($this->getPosition()) <= 2;
	}

	public function doArmSwingAnimation(): void {
		$pk = new ActorEventPacket();
		$pk->eventId = ActorEvent::ARM_SWING;
		$pk->actorRuntimeId = $this->getId();
		$this->getWorld()->broadcastPacketToViewers($this->getPosition(), $pk);
	}
}