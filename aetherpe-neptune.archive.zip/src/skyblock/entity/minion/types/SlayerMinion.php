<?php

declare(strict_types=1);

namespace skyblock\entity\minion\types;

use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\item\Sword;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\CompoundTag;
use skyblock\entity\minion\BaseMinion;
use skyblock\entity\Mob;
use skyblock\utils\IslandUtils;

class SlayerMinion extends BaseMinion {

	public Sword $sword;

	public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null){
		$this->sword = VanillaItems::DIAMOND_SWORD();

		parent::__construct($location, $skin, $nbt);
	}

	protected function initEntity(CompoundTag $nbt) : void{
		parent::initEntity($nbt);

		$this->getInventory()->setItemInHand($this->sword);
	}

	protected function onTick() : void{
		if($this->getInt("durability", 200) <= 0){
			$this->setNameTag("§c§lBROKEN SWORD");
			$this->setNameTagAlwaysVisible(true);
			return;
		} else {
			$this->setNameTagAlwaysVisible(false);
			$this->setNameTag($this->getDefaultNametag());
		}


		$e = $this->getPosition()->getWorld()->getNearestEntity($this->getPosition(), 5, Mob::class);

		if(!$e instanceof Mob) return;

		$drops = $e->getDrops();

		$adds = false;

		foreach($drops as $drop){
			if($this->getMinionInventory()->canAddItem($drop)){
				if(mt_rand(1, 2) === 1){
					$this->getMinionInventory()->addItem($drop->setCount($drop->getCount() + mt_rand(0, $this->getInt("looting", 0))));
				} else $this->getMinionInventory()->addItem($drop);

				$adds = true;
			}
		}

		if($adds === false) return;


		if($e->getStackSize() > 1){
			$e->decreaseStackSize(1);
		} else $e->flagForDespawn();

		$this->setInt("xp", $this->getInt("xp", 0) + 1);
		$this->setInt("collectableXP", $this->getInt("collectableXP", 0) + $e->getXpDropAmount());
		$this->setInt("durability", $this->getInt("durability", $this->sword->getMaxDurability()) - 1);

		$this->checkLevel();
	}

	protected function getTickDelay() : int{
		return $this->getInt("speed", 100);
	}

	protected function getInventorySize() : int{
		return $this->getInt("size", 54);
	}

	protected function onLevelUp(int $oldLevel, int $newLevel) : void{
		$string = "";
		switch(mt_rand(1, 4)){
			case 1:
				if($this->getInt("speed", 100) <= 40){
					$this->onLevelUp($oldLevel, $newLevel);
					return;
				}

				$old = $this->getInt("speed", 100);
				$new = $old - 10;
				$this->setInt("speed", $new);

				$string = "§r§l§4 * §r§aAttack Speed: §a" . ($old / 20) . "s" . " > " . ($new / 20) . "s! §lLEVEL UP";
				break;
			case 2:
				if($this->getInt("looting", 0) <= 3){
					$this->onLevelUp($oldLevel, $newLevel);
					return;
				}
				$old = ($this->getInt("looting", 0));
				$new = $old + 1;

				$this->setInt("looting", $new);
				$string = "§r§l§4 * §r§aLooting: §a$old > $new! §lLEVEL UP";

				break;
			case 3:
				$old = ($this->getInt("maxDurability", $this->sword->getMaxDurability()));
				$new = $old * 2;
				$this->setInt("maxDurability",  $new);

				$string = "§r§l§4 * §r§aMax Durability: §a$old > $new! §lLEVEL UP";
				break;
			case 4:
				$old = $this->getInventorySize();
				$new = $old + 54;

				$this->setInt("size", $new);
				$string = "§r§l§4 * §r§aInventory Slots: §a$old > $new! §lLEVEL UP";
				break;
		}

		$island = IslandUtils::getIslandByWorld($this->getWorld());
		if($island->exists() && $string !== ""){
			$members = array_merge([$island->getLeader()], $island->getMembers());

			$island->announce(" ", $members);
			$island->announce("§r§7A minion in your island just leveled up!", $members);
			$island->announce("§r§l§4Slay§cer §4Min§cion §r§7[LVL $oldLevel] is now level $newLevel", $members);
			$island->announce($string, $members);
			$island->announce("§r§7Minion Coordinates: {$this->getLocation()->getFloorX()}x {$this->getLocation()->getFloorY()}y {$this->getLocation()->getFloorZ()}z", $members);
			$island->announce(" ", $members);
		}
	}

	protected function getFormText() : array{
		return [
			"§r§l§8Minion Info",
			"§r§l§8 * §r§7Attack Speed: §a" . ($this->getInt("speed", 50) / 20) . "s",
			"§r§l§8 * §r§7Looting Level: §a" . ($this->getInt("looting", 0)),
			"§r§l§8 * §r§7Minion Sword Durability: §a" . ($this->getInt("durability", $this->sword->getMaxDurability())) . "§7/§c" . $this->getInt("maxDurability", $this->sword->getMaxDurability()),
			"§r§l§8 * §r§7XP Farmed: §a" . ($this->getInt("collectableXP", 0)),
			"§r§l§8 * §r§7Inventory Slots: §a" . ($this->getInventorySize()),
			"§r",
			"§r§l§8Minion Level",
			"§r§l§8 * §r§7Minion Level: §a" . ($this->getInt("level", 1)),
			"§r§l§8 * §r§7Minion EXP: §a" . $this->getInt("xp") . "§7/§c" . self::getNeededXP($this->getInt("level", 1)),
		];
	}

	protected function getSavingKeys() : array{
		$arr = parent::getSavingKeys();
		$arr[] = "looting";
		$arr[] = "durability";
		$arr[] = "maxDurability";
		$arr[] = "collectableXP";


		return $arr;
	}
}