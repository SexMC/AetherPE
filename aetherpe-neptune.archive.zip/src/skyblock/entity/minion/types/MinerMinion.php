<?php

declare(strict_types=1);

namespace skyblock\entity\minion\types;

use pocketmine\block\BlockLegacyIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\item\ItemIds;
use pocketmine\item\Pickaxe;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\CompoundTag;
use skyblock\entity\minion\BaseMinion;
use skyblock\utils\IslandUtils;

class MinerMinion extends BaseMinion {

	public const ALLOWED_BLOCK_IDS = [BlockLegacyIds::DIAMOND_ORE, BlockLegacyIds::EMERALD_ORE, BlockLegacyIds::REDSTONE_ORE, BlockLegacyIds::GLOWING_REDSTONE_ORE, BlockLegacyIds::COBBLESTONE, BlockLegacyIds::STONE, BlockLegacyIds::IRON_ORE, BlockLegacyIds::GOLD_ORE, BlockLegacyIds::LAPIS_ORE, BlockLegacyIds::COAL_ORE];
	public const ALLOWED_FORTUNE_IDS = [ItemIds::COAL, ItemIds::IRON_INGOT, ItemIds::REDSTONE, ItemIds::DIAMOND, ItemIds::EMERALD, ItemIds::GOLD_INGOT, ItemIds::DYE];
	
	public Pickaxe $pickaxe;

	public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null){
		$this->pickaxe = VanillaItems::DIAMOND_PICKAXE();

		parent::__construct($location, $skin, $nbt);
	}

	protected function initEntity(CompoundTag $nbt) : void{
		parent::initEntity($nbt);

		$this->getInventory()->setItemInHand($this->pickaxe);
	}

	protected function getSavingKeys() : array{
		$parent = parent::getSavingKeys();
		$parent[] = "fortune";
		$parent[] = "durability";
		$parent[] = "essence";
		$parent[] = "maxDurability";

		return $parent;
	}

	protected function onTick() : void{
		if($this->getInt("durability", 200) <= 0){
			$this->setNameTag("§c§lBROKEN PICKAXE");
			$this->setNameTagAlwaysVisible(true);
			return;
		} else {
			$this->setNameTagAlwaysVisible(false);
			$this->setNameTag($this->getDefaultNametag());
		}


		$block = $this->getTargetBlock(4);

		if(!in_array($block->getId(), self::ALLOWED_BLOCK_IDS)){
			return;
		}

		$drops = $block->getDrops($this->pickaxe);
		$can = false;

		foreach($drops as $drop){
			if($this->getMinionInventory()->canAddItem($drop)){
				if(in_array($drop->getId(), self::ALLOWED_FORTUNE_IDS)){
					$this->getMinionInventory()->addItem($drop->setCount($drop->getCount() + (mt_rand(0, $this->getInt("fortune", 0)))));
				} else $this->getMinionInventory()->addItem($drop);
				$can = true;
			}
		}

		if($can === false){
			return;
		}

		$this->getWorld()->setBlock($block->getPosition(), VanillaBlocks::AIR());
		$this->swingArm();

		$this->setInt("xp", $this->getInt("xp", 0) + 1);
		$this->setInt("essence", $this->getInt("essence", 0) + 1);
		$this->setInt("durability", $this->getInt("durability", $this->pickaxe->getMaxDurability()) - 1);

		$this->checkLevel();
	}

	protected function getTickDelay() : int{
		return $this->getInt("speed", 80);
	}

	protected function getInventorySize() : int{
		return $this->getInt("size", 54);
	}

	protected function onLevelUp(int $oldLevel, int $newLevel) : void{
		$string = "";

		switch(mt_rand(1, 4)){
			case 1:
				if($this->getInt("speed", 50) <= 20){
					$this->onLevelUp($oldLevel, $newLevel);
					return;
				}

				$old = $this->getInt("speed", 100);
				$new = $old - 10;
				$this->setInt("speed", $new);

				$string = "§r§l§8 * §r§aMine Speed: §a" . ($old / 20) . "s" . " > " . ($new / 20) . "s! §lLEVEL UP";
				break;
			case 2:
				if($this->getInt("fortune", 0) <= 3){
					$this->onLevelUp($oldLevel, $newLevel);
					return;
				}
				$old = ($this->getInt("fortune", 0));
				$new = $old + 1;

				$this->setInt("fortune", $new);
				$string = "§r§l§8 * §r§aFortune: §a$old > $new! §lLEVEL UP";
				break;
			case 3:
				$old = ($this->getInt("maxDurability", $this->pickaxe->getMaxDurability()));
				$new = $old * 2;
				$this->setInt("maxDurability",  $new);

				$string = "§r§l§8 * §r§aMax Durability: §a$old > $new! §lLEVEL UP";
				break;
			case 4:
				$old = $this->getInventorySize();
				$new = $old + 54;

				$this->setInt("size", $new);
				$string = "§r§l§8 * §r§aInventory Slots: §a$old > $new! §lLEVEL UP";
				break;
		}

		$island = IslandUtils::getIslandByWorld($this->getWorld());
		if($island->exists() && $string !== ""){
			$members = array_merge([$island->getLeader()], $island->getMembers());

			$island->announce(" ", $members);
			$island->announce("§r§7A minion in your island just leveled up!", $members);
			$island->announce("§r§l§8Min§7er §8Min§7ion §r§7[LVL $oldLevel] is now level $newLevel", $members);
			$island->announce($string, $members);
			$island->announce("§r§7Minion Coordinates: {$this->getLocation()->getFloorX()}x {$this->getLocation()->getFloorY()}y {$this->getLocation()->getFloorZ()}z", $members);
			$island->announce(" ", $members);
		}
	}

	protected function getFormText() : array{
		return [
			"§r§l§8Minion Info",
			"§r§l§8 * §r§7Mine Speed: §a" . ($this->getInt("speed", 80) / 20) . "s",
			"§r§l§8 * §r§7Fortune Level: §a" . ($this->getInt("fortune", 0)),
			"§r§l§8 * §r§7Minion Pickaxe Durability: §a" . ($this->getInt("durability", $this->pickaxe->getMaxDurability())) . "§7/§c" . $this->getInt("maxDurability", $this->pickaxe->getMaxDurability()),
			"§r§l§8 * §r§7Essence Farmed: §a" . ($this->getInt("essence", 0)),
			"§r§l§8 * §r§7Inventory Slots: §a" . ($this->getInventorySize()),
			"§r",
			"§r§l§8Minion Level",
			"§r§l§8 * §r§7Minion Level: §a" . ($this->getInt("level", 1)),
			"§r§l§8 * §r§7Minion EXP: §a" . $this->getInt("xp") . "§7/§c" . self::getNeededXP($this->getInt("level", 1)),
		];
	}
}