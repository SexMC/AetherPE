<?php

declare(strict_types=1);

namespace skyblock\entity\minion;

use muqsit\invmenu\transaction\InvMenuTransaction;
use pocketmine\entity\AttributeMap;
use pocketmine\entity\Human;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\inventory\Inventory;
use pocketmine\inventory\SimpleInventory;
use pocketmine\item\Item;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\ActorEventPacket;
use pocketmine\network\mcpe\protocol\AnimatePacket;
use pocketmine\network\mcpe\protocol\types\ActorEvent;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use skyblock\forms\commands\nbt\NBTItemForm;
use skyblock\forms\minion\MinionForm;
use skyblock\items\special\SpecialItem;
use skyblock\items\special\types\SellWandItem;
use skyblock\Main;
use skyblock\menus\common\ViewPagedItemsMenu;
use skyblock\menus\minions\MinionInventoryMenu;

abstract class BaseMinion extends Human {

	/** @var array<string, string> */
	private array $stringMap = [];
	/** @var array<string, int> */
	private array $intMap = [];

	private int $currentTick = 0;
	private int $tickDelay = -1;

	private SimpleInventory $minionInventory;

	protected function initEntity(CompoundTag $nbt) : void{
		parent::initEntity($nbt);
		$this->setScale(0.75);

		foreach($this->getSavingKeys() as $key){
			$key = strtolower($key);

			if(($tag = $nbt->getTag($key)) !== null){
				if($tag instanceof StringTag){
					$this->stringMap[$key] = $tag->getValue();
				}

				if($tag instanceof IntTag){
					$this->intMap[$key] = $tag->getValue();
				}
			}
		}


		$this->updateInventory();
		foreach(($nbt->getListTag("minionInventory")?->getValue() ?? []) as $tag){
			$this->minionInventory->addItem(Item::nbtDeserialize($tag));
		}
	}

	public function openInventory(Player $player): void {
		$size = $this->getInventorySize();
		$menu = (new MinionInventoryMenu($this, "§7Minion Inventory (§c{$size}§7)", $this->minionInventory->getContents()));

		$menu->send($player);
	}

	public function attack(EntityDamageEvent $source) : void{
		if($source instanceof EntityDamageByEntityEvent){
			$player = $source->getDamager();

			if(!$player instanceof Player){
				return;
			}

			if($player->getName() !== $this->getString("owner", "") && !Server::getInstance()->isOp($player->getName())){
				$player->sendMessage(Main::PREFIX . "You can only open your own minions");
				return;
			}

			$item = $player->getInventory()->getItemInHand();
			if($item->getNamedTag()->getString(SpecialItem::TAG_SPECIAL_ITEM, "") === SellWandItem::getItemTag()){
				SellWandItem::sellInventoryWithSellWand($player, $item, $this->getMinionInventory());

				return;
			}

			$player->sendForm(new MinionForm($this, implode(TextFormat::EOL, $this->getFormText())));
		}

		$source->cancel();
	}

	public function updateInventory(array $contents = []): void {
		$this->minionInventory = new SimpleInventory($this->getInventorySize());
		$this->minionInventory->setContents($contents);
	}

	public function onUpdate(int $currentTick) : bool{
		if($this->tickDelay === -1) {
			$this->tickDelay = $this->getTickDelay();
		}

		if(++$this->currentTick >= $this->tickDelay){
			$this->currentTick = 0;
			$this->tickDelay = $this->getTickDelay();

			$this->onTick();
		}

		return parent::onUpdate($currentTick);
	}

	public function saveNBT() : CompoundTag{
		$nbt = parent::saveNBT();

		foreach($this->intMap as $key => $value){
			$nbt->setInt($key, $value);
		}

		foreach($this->stringMap as $key => $value){
			$nbt->setString($key, $value);
		}

		$inventoryTag = new ListTag([], NBT::TAG_Compound);
		if($this->minionInventory !== null){
			foreach($this->minionInventory->getContents() as $content){
				$inventoryTag->push($content->nbtSerialize());
			}
		}
		$nbt->setTag("minionInventory", $inventoryTag);

		return $nbt;
	}

	public function getInt(string $key, int $default = null): ?int {
		return $this->intMap[strtolower($key)] ?? $default;
	}

	public function getString(string $key, string $default = null) : ?string{
		return $this->stringMap[strtolower($key)] ?? $default;
	}

	public function setString(string $key, string $value) : void{
		$this->stringMap[strtolower($key)] = $value;
	}

	public function setInt(string $key, int $value): void {
		$this->intMap[strtolower($key)] = $value;
	}

	public function getOwner(): string {
		return $this->getString("owner");
	}

	protected function getSavingKeys(): array {
		return [
			"owner",
			"level",
			"xp",
			"size",
			"speed"
		];
	}

	public function getMinionInventory() : SimpleInventory{
		return $this->minionInventory;
	}

	protected function checkLevel(): void {
		if($this->getInt("xp", 1) >= self::getNeededXP($this->getInt("level", 1))){
			$level = $this->getInt("level", 1);

			$this->onLevelUp($level, $level + 1);

			$this->setInt("level", $level + 1);
			$this->setInt("xp", 1);
		}
	}

	protected function swingArm(): void {
		Server::getInstance()->broadcastPackets($this->getViewers(), [ActorEventPacket::create($this->id, ActorEvent::ARM_SWING, 0)]);
	}

	protected abstract function onTick(): void;
	protected abstract function getTickDelay(): int;
	protected abstract function getInventorySize(): int;
	protected abstract function onLevelUp(int $oldLevel, int $newLevel): void;
	protected abstract function getFormText(): array;


	public static function getNeededXP(int $level): int {
		return $level * 2000;
	}

	public function getDefaultNametag(): string {
		return "§c{$this->getString("owner", "error")}'s Minion";
	}
}