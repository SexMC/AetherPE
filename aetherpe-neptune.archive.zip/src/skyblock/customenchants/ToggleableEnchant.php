<?php

declare(strict_types=1);

namespace skyblock\customenchants;

use pocketmine\item\Armor;
use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\player\Player;
use skyblock\items\ItemEditor;
use skyblock\utils\CustomEnchantUtils;

abstract class ToggleableEnchant extends CustomEnchant {

	public static array $array = [];

	private array $toggled = [];

	abstract function toggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance): void;

	abstract function unToggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance): void;

	public function isToggled(Player $player): bool {
		return isset($this->toggled[$player->getName()]);
	}

	public function addToggled(Player $player): void {
		$this->toggled[$player->getName()] = 1;
	}

	public function removeToggled(Player $player): void {
		unset($this->toggled[$player->getName()]);
	}

	public function checkToggle(Player $player, Item $newItem, Item $oldItem, CustomEnchantInstance $enchantInstance): void {
		$id = $this->identifier->getId();


		if(ItemEditor::hasEnchantment($oldItem, $id) && !ItemEditor::hasEnchantment($newItem, $id)){
			$this->unToggle($player, $oldItem, $enchantInstance);
			$this->removeToggled($player);
		} elseif(!ItemEditor::hasEnchantment($oldItem, $id) && ItemEditor::hasEnchantment($newItem, $id)){
            $level = ItemEditor::getCustomEnchantLevel($newItem, $id);
            if ($level < 1) {
                ItemEditor::removeCustomEnchant($newItem, $id);
                return;
            }

			if(!$this->isToggled($player)){
				if($this->getIdentifier()->isImportant()){
					$player->sendMessage($this->getActivateMessage($player));
				}
				$this->toggle($player, $newItem, $enchantInstance);
				$this->addToggled($player);

				if($newItem instanceof Tool){
					if(isset(self::$array[$player->getName()])){
						self::$array[$player->getName()][] = $enchantInstance;
					} else self::$array[$player->getName()] = [$enchantInstance];
				}
			}
		}
	}

	/**
	 * @param Item $item
	 *
	 * @return CustomEnchantInstance[]
	 */
	public static function getToggleables(Item $item): array {

		$toggle = [];

		foreach(ItemEditor::getCustomEnchantments($item) as $customEnchantInstance){
			$ce = $customEnchantInstance->getCustomEnchant();
			if(!$ce instanceof ToggleableEnchant) continue;

			if(isset($toggle[$ce::class]) && $customEnchantInstance->getLevel() <= $toggle[$ce::class]->getLevel()){
				continue;
			}

			$toggle[$ce::class] = $customEnchantInstance;
		}


		return $toggle;
	}
}