<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\item\Axe;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class Dominate extends ReactiveEnchant {

	private static array $array = [];

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(4);
		$this->setDescription("Chance to weaken enemy players on hit, causing them to deal (level x 5%) less damage to players for (level x 2) seconds.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("dominate", "Dominate", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$entity = $event->getEntity();
			$damager = $event->getDamager();
			if($entity instanceof Player && $damager instanceof Player){
				$damage = $enchantInstance->getLevel() * 5 / 100;
				$time = $enchantInstance->getLevel() * 2;

				self::$array[$entity->getName()] = [$damage, $time, time()];
				$entity->sendMessage("§r§l§6** Dominate (§r§7You will now deal less damage to {$damager->getName()}§l§6) (§r§7-$damage%§l§6)**");

				//the dealing less damage will be in customenchants listener
			}
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && $event->getEntity() instanceof Player && mt_rand(1, 100) <= 2;
	}

	public static function applyDomination(Player $player, CustomEntityDamageByEntityEvent $event): void {
		$data = self::$array[$player->getName()] ?? [];

		if(empty($data)){
			return;
		}
		
		$damage = $data[0];
		$time = $data[1];
		$started = $data[2];
		
		if(time() - $started >= $time){
			unset(self::$array[$player->getName()]);
			return;
		}
		
		$event->divideDamage($damage, "dominate");
	}
}