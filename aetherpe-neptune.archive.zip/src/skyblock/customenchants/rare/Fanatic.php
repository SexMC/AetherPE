<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\item\Axe;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class Fanatic extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(5);
		$this->setDescription("Deal increased DMG to enemy players that are wielding an axe.");
		$this->setApplicableTo(self::ITEM_AXE);

		return new CustomEnchantIdentifier("fanatic", "Fanatic", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$event->multiplyDamage($msg = (0.05 * $enchantInstance->getLevel()), "fanatic");
			$player->sendMessage("§r§l§a** Fanatic (§r§7+$msg% Outgoing Damage§l§a) **");
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		if($event instanceof CustomEntityDamageByEntityEvent){
			if($player->getId() === $event->getDamager()->getId()){
				$ent = $event->getEntity();

				if($ent instanceof Player && $ent->getInventory()->getItemInHand() instanceof Axe){
					return true;
				}
			}
		}

		return false;
	}
}