<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\item\Axe;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class ArmorRot extends ReactiveEnchant {

	private static array $array = [];

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(4);
		$this->setDescription("Increases durability loss on your enemy's armor.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("armor_rot", "Armor Rot");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$entity = $event->getEntity();
			if($entity instanceof Player){
				$entity->damageArmor(mt_rand(0, $enchantInstance->getLevel()));
			}
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && $event->getEntity() instanceof Player;
	}
}