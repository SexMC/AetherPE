<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\item\Axe;
use pocketmine\item\Durable;
use pocketmine\item\Item;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class Blacksmith extends ReactiveEnchant {

	private static array $array = [];

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(5);
		$this->setDescription("Chance to regenerate durability on your most damaged piece of armor by 1-2 durability whenever you damage a player, but when activated your attack deals 50% of the normal damage.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("blacksmith", "Blacksmith");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$result = null;
			$index = 0;
			$lastDura = 0;
			foreach($player->getArmorInventory()->getContents() as $i => $item) {
				if($item instanceof Durable){
					if($lastDura > $item->getDamage()) {
						$lastDura = $item->getDamage();
						$result = $item;
						$index = $i;
					}
				}
			}
			if($result instanceof Durable) {
				$result->setDamage($result->getDamage() - mt_rand(1,2));
				$player->getArmorInventory()->setItem($index, $result);
				$event->divideDamage(2, "blacksmith");
			}
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel();
	}
}