<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;


use pocketmine\event\Event;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacketV1;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use pocketmine\player\Player;
use pocketmine\world\sound\ClickSound;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\LightningEntity;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\utils\EntityUtils;

class Electrify extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(4);
		$this->setDescription("Chance to strike lightning on the attacking player.");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("electrify", "Electrify");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$volumes = [0.1, 0.2, 0.3, 0.4];
			$pitches = [0.2, 0.3];

			for($i = 1; $i <= $enchantInstance->getLevel(); $i++){
				$volume = mt_rand(0, 3);
				$pitch = mt_rand(0, 1);
				EntityUtils::spawnLightning($player->getLocation(), $volumes[$volume], $pitches[$pitch]);
			}

			$event->getDamager()->setOnFire(4 * $enchantInstance->getLevel());
			$this->setCooldown($player, 60);
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel() * 2.5 && !$this->isOnCooldown($player);
	}
}