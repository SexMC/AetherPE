<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;


use pocketmine\event\Event;
use pocketmine\item\Axe;
use pocketmine\item\Sword;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacketV1;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use pocketmine\player\Player;
use pocketmine\world\sound\ClickSound;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\LightningEntity;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\utils\EntityUtils;

class AntiAxe extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(4);
		$this->setDescription("Decreases damage from enemy axes, scaling with level.");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("anti_axe", "Anti Axe", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$divide = 0.025 * $enchantInstance->getLevel();

			$event->divideDamage($divide, "anti axe");
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$damager = $event->getDamager();

			if($damager instanceof Player && $player->getId() === $event->getEntity()->getId()){
				if($damager->getInventory()->getItemInHand() instanceof Axe){
					return true;
				}
			}
		}

		return false;
	}
}