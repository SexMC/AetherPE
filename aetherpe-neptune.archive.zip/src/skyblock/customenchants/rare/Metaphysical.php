<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;


use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\utils\EntityUtils;

class Metaphysical extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([EntityEffectAddEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(4);
		$this->setDescription("A chance to block slowness");
		$this->setApplicableTo(self::ITEM_BOOTS);

		return new CustomEnchantIdentifier("metaphysical", "Metaphysical", true);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof EntityEffectAddEvent){
			$event->cancel();

			$this->setCooldown($player, 15);
			EntityUtils::spawnTextEntity($player->getLocation(), "§r§l§3[METAPHYSICAL - Slowness Blocked]", 4);
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof EntityEffectAddEvent && $event->getEffect()->getType()->getName() === VanillaEffects::SLOWNESS()->getName() && $player->getId() === $event->getEntity()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel() * 3 && !$this->isOnCooldown($player);
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§a** Metaphysical (§r§7Removed Slowness Effects§l§a) **";
	}
}