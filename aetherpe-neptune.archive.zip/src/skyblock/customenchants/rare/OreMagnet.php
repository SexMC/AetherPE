<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;


use pocketmine\block\BlockLegacyIds;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\Event;
use pocketmine\item\ItemIds;
use pocketmine\network\mcpe\protocol\ItemFrameDropItemPacket;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;
use skyblock\utils\EntityUtils;

class OreMagnet extends ReactiveEnchant {

	public const ORES = [
		BlockLegacyIds::EMERALD_ORE => ItemIds::EMERALD . ":0",
		BlockLegacyIds::COAL_ORE => ItemIds::COAL . ":0",
		BlockLegacyIds::REDSTONE_ORE => ItemIds::REDSTONE . ":0",
		BlockLegacyIds::LAPIS_ORE => ItemIds::DYE . ":4",
		BlockLegacyIds::DIAMOND_ORE => ItemIds::DIAMOND . ":0"
	];

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([BlockBreakEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(5);
		$this->setDescription("Chance to receive more ores.");
		$this->setApplicableTo(self::ITEM_PICKAXE);

		return new CustomEnchantIdentifier("ore_magnet", "Ore Magnet");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof BlockBreakEvent) {
			foreach($event->getDrops() as $drop){
				if(in_array($drop->getId() . ":" . $drop->getMeta(), self::ORES)){
					$drop->setCount($drop->getCount() + mt_rand(1, $enchantInstance->getLevel()));
				}
			}
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool{
		return $event instanceof BlockBreakEvent && mt_rand(1, 150) <= $enchantInstance->getLevel() && in_array($event->getBlock()->getId(), self::ORES);
	}
}