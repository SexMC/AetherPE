<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class AdrenalineRush extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(3);
		$this->setDescription("Chance to receive a speed and regeneration when you're face to face with death.");
		$this->setApplicableTo(self::ITEM_BOOTS_AND_HELMET);

		return new CustomEnchantIdentifier("adrenaline_rush", "Adrenaline Rush");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::SPEED(), 20 * 5, 3)));
			$player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::REGENERATION(), 20 * 5, 2)));
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId() && $player->getHealth() <= 10 && mt_rand(1, 100) <= $enchantInstance->getLevel() * 5;
	}
}