<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\item\Item;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ToggleableEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class Haste extends ToggleableEnchant {
	public function prepare() : CustomEnchantIdentifier{
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(3);
		$this->setDescription("Allows you to swing your tools faster.");
		$this->setApplicableTo(self::ITEM_TOOLS);

		return new CustomEnchantIdentifier("haste", "Haste", false);
	}

	function toggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		$player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::HASTE(), 20 * 99999, $enchantmentInstance->getLevel() - 1)));
	}

	function unToggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		$player->getEffects()->remove(VanillaEffects::HASTE());
	}
}