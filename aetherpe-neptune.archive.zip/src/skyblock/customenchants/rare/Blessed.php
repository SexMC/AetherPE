<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\item\Axe;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class Blessed extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class, EntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(4);
		$this->setDescription("A chance of removing debuffs");
		$this->setApplicableTo(self::ITEM_AXE);

		return new CustomEnchantIdentifier("blessed", "Blessed");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof EntityDamageByEntityEvent){
			foreach($player->getEffects()->all() as $effectInstance){
				if($effectInstance->getType()->isBad()){
					$player->getEffects()->remove($effectInstance->getType());
				}
			}
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		if($event instanceof EntityDamageByEntityEvent){
			return $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel() * 3;
		}

		return false;
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§e** Blessed (§r§7Negative Effects Gone§l§e) **";
	}
}