<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\item\Axe;
use pocketmine\network\mcpe\protocol\StopSoundPacket;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\world\sound\ClickSound;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;
use skyblock\utils\EntityUtils;
use skyblock\utils\Utils;

class Silence extends ReactiveEnchant {

	private static $silenced = [];

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(4);
		$this->setDescription("Chance to prevent activation of your enemies custom enchants.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("silence", "Silence", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$this->setCooldown($player, 60);

			$player = $event->getEntity();

			if(!$player instanceof Player) return;

			self::setSilenced($player, $time = ($enchantInstance->getLevel() * 2));
			$player->sendMessage("§r§l§d** Silence (§r§7Silenced for $time second§l§d) **");

			$player->getNetworkSession()->sendDataPacket(EntityUtils::getSoundPacket("mob.endermen.stare", $player->getLocation(), 1, 1.8));
			Utils::executeRepeatedlyFor(function() use ($player) : void{
				if($player->isOnline()){
					$left = self::timeLeft($player);
					$player->sendMessage("§r§l§d* Silenced §r§d{$left}s");

					if($left === 1){
						$pk = new StopSoundPacket();
						$pk->soundName = "mob.endermen.stare";
						$pk->stopAll = false;
						$player->getNetworkSession()->sendDataPacket($pk);
					}
				}
			}, 20, 0, $enchantInstance->getLevel() * 2 - 1);
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		if($event instanceof CustomEntityDamageByEntityEvent){
			if($event->getDamager()->getId() === $player->getId() && $event->getEntity() instanceof Player && mt_rand(1, 175) <= $enchantInstance->getLevel() && !$this->isOnCooldown($event->getEntity())){
				return !$this->isOnCooldown($player);
			}
		}

		return false;
	}

	public static function setSilenced(Player $player, int $seconds): void {
		self::$silenced[$player->getName()] = [$seconds, time()];
	}

	public static function timeLeft(Player $player): int {
		$data = self::$silenced[$player->getName()] ?? [];

		if(empty($data)){
			return 0;
		}


		$seconds = $data[0];
		$started = $data[1];

		if(time() - $started > $seconds){
			unset(self::$silenced[$player->getName()]);
			return 0;
		}


		return $seconds -  (time() - $started);
	}

	public static function isSilenced(Player $player): bool {
		$data = self::$silenced[$player->getName()] ?? [];

		if(empty($data)){
			return false;
		}


		$seconds = $data[0];
		$started = $data[1];

		if(time() - $started > $seconds){
			unset(self::$silenced[$player->getName()]);
			return false;
		}


		return true;
	}
}