<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;


use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;
use skyblock\utils\EntityUtils;

class MoneyMiner extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([BlockBreakEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(4);
		$this->setDescription("Chance to yield money while mining");
		$this->setApplicableTo(self::ITEM_PICKAXE);

		return new CustomEnchantIdentifier("money_miner", "Money Miner");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		$session = new Session($player);
		$session->increaseMoney(mt_rand(1000, 6500 + (($enchantInstance->getLevel() - 1) * 2500)));
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool{
		return $event instanceof BlockBreakEvent && mt_rand(1, 1500) <= $enchantInstance->getLevel();
	}
}