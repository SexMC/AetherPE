<?php

declare(strict_types=1);

namespace skyblock\customenchants\rare;

use pocketmine\block\VanillaBlocks;
use pocketmine\event\Event;
use pocketmine\player\Player;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\world\sound\BlockBreakSound;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class Cleave extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(7);
		$this->setDescription("Damage enemies within an increasing radius depending on enchantment level.");
		$this->setApplicableTo(self::ITEM_AXE);

		return new CustomEnchantIdentifier("cleave", "Cleave");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$this->setCooldown($player, 35);

			$level = $enchantInstance->getLevel();
			$session = new Session($player);
			$members = [];

			if(($is = $session->getIslandName()) !== null){
				$island = new Island($is);
				$members = array_merge($island->getMembers(), [$island->getLeader()]);
			}

			foreach ($player->getWorld()->getNearbyEntities($player->getBoundingBox()->expandedCopy($level, $level, $level), $player) as $entity) {
				if (!$entity instanceof Player) {
					return;
				}

				if (in_array($entity->getName(), $members)) {
					continue;
				}

				$entity->setHealth($entity->getHealth() - mt_rand(3, 4));
				$entity->getWorld()->addParticle($entity->getLocation(), new BlockBreakParticle(VanillaBlocks::GOLD()));
				$entity->getWorld()->addSound($entity->getLocation(), new BlockBreakSound(VanillaBlocks::GOLD()), [$entity]);
			}
		}
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§b** Cleave (§r§7Slight Burst of Damage§l§b) **";
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		if($event instanceof CustomEntityDamageByEntityEvent){
			if($event->getDamager()->getId() === $player->getId() && $event->getEntity() instanceof Player && mt_rand(1, 100) <= $enchantInstance->getLevel() && !$this->isOnCooldown($player)){
				return true;
			}
		}

		return false;
	}
}