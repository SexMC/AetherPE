<?php

declare(strict_types=1);

namespace skyblock\customenchants;

use JetBrains\PhpStorm\Pure;
use pocketmine\entity\Entity;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\rare\Silence;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\ItemEditor;
use skyblock\misc\warpspeed\IWarpSpeed;
use skyblock\misc\warpspeed\WarpSpeedHandler;

abstract class ReactiveEnchant extends CustomEnchant {

    /** @var string[] */
    private array $events = [];

	private array $cooldowns = [];

	public function setCooldown(Player $player, int $time): void {
		$this->cooldowns[$player->getName()] = [$time, time()];
	}

	public function isOnCooldown(Player $player): bool {
		$data = $this->cooldowns[$player->getName()] ?? [];

		if(empty($data)){
			return false;
		}

		$seconds = $data[0];
		$started = $data[1];

		if(time() - $started > $seconds){
			unset($this->cooldowns[$player->getName()]);
			return false;
		}


		return true;
	}

    public function getEvents(): array {
        return $this->events;
    }

    public function setEvents(array $events): void {
        $this->events = $events;
    }

    abstract public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void;

	/**
	 * @param Player                $player
	 * @param Event                 $event
	 * @param CustomEnchantInstance $enchantInstance
	 *
	 * @return bool if true do the negation in here
	 */
    abstract public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool;

	/**
	 * @param Player $player
	 *
	 * @return CustomEnchant[]
	 */
	public static function setupCustomReaction(CustomEntityDamageByEntityEvent $event): void {
		$entity = $event->getEntity();
		$damager = $event->getDamager();

		if($entity instanceof Player){
			if(!Silence::isSilenced($entity)){
				$event->getEntityCustomEnchantsReactionManager()->set(self::getActivatingCustomEnchants($entity, $event));
			}
		}

		if($damager instanceof Player){
			if(!Silence::isSilenced($damager)){
				$event->getDamagerCustomEnchantsReactionManager()->set(self::getActivatingCustomEnchants($damager, $event));
			}
		}
	}

	public static function doReaction(Player $player, Event $event): void {
		$all = self::getActivatingCustomEnchants($player, $event);

		foreach($all as $enchantInstance){
			/** @var ReactiveEnchant $ce */
			$ce = $enchantInstance->getCustomEnchant();
			
			if($ce->getIdentifier()->isImportant()){
				$player->sendMessage($ce->getActivateMessage($player));
			}
			$ce->Reaction($player, $event, $enchantInstance);
		}
	}


	/**
	 * @param Player $player
	 * @param Event  $event
	 *
	 * @return CustomEnchantInstance[]
	 */
	private static function getActivatingCustomEnchants(Player $player, Event $event): array {
		$class = $event::class;

		/** @var CustomEnchantInstance[] $v */
		$v = [];
		foreach(array_merge($player->getArmorInventory()?->getContents(), [$player->getInventory()?->getItemInHand()]) as $item){
			if($item === null) continue;

			foreach(ItemEditor::getCustomEnchantments($item) as $enchantInstance){
                $ce = $enchantInstance->getCustomEnchant();
                if($ce instanceof ReactiveEnchant && in_array($class, $ce->getEvents())){
					if($ce->getRarity()->getTier() === ICustomEnchant::RARITY_HEROIC){
						if(!WarpSpeedHandler::getInstance()->isUnlocked(IWarpSpeed::HEROIC_ENCHANTMENTS)) continue;
					}

                    if ($enchantInstance->getLevel() < 1) {
                        ItemEditor::removeCustomEnchant($item, $ce->getIdentifier()->getId());
                        continue;
                    }

                    if(isset($v[$ce::class]) && ($v[$ce::class]->getLevel() >= $enchantInstance->getLevel())){
						continue;
					}

					$v[$ce::class] = $enchantInstance;
				}

			}
		}

		foreach($v as $enchantInstance){
			/** @var ReactiveEnchant $ce */
			$ce = $enchantInstance->getCustomEnchant();

			if($ce->preReaction($player, $event, $enchantInstance) === false){
				unset($v[$ce::class]);
			}
		}



		return $v;
	}
}