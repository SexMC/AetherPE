<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Spiked extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_ARMOUR);
        $this->setMaxLevel(2);
        $this->setDescription("A (Level * 2.5)% chance to injure your attacker for (Level * 1)HP but does not affect your durability (does not refresh rage stacks).");

        return new CustomEnchantIdentifier("spiked", "Spiked", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $damager->setHealth($damager->getHealth() - $enchantInstance->getLevel() * 2);
				$player->sendMessage("§r§l§b** Spiked (§r§7-2 HP to {$damager->getName()}§l§b) **");
            }
        }
    }

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId() && mt_rand(1, 100) < $enchantInstance->getLevel() * 2.5;
    }
}