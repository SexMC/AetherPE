<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use JetBrains\PhpStorm\Pure;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Event;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\items\rarity\Rarity;

class AutoSmelt extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([BlockBreakEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_PICKAXE);
        $this->setMaxLevel(3);
        $this->setDescription("Automatically smelt ores to ingots.");

        return new CustomEnchantIdentifier("auto_smelt", "Auto Smelt", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof BlockBreakEvent) {
            $newDrops = $event->getDrops();
            foreach ($newDrops as $k => $drop) {

                $newId = match ($drop->getId()) {
                    ItemIds::IRON_ORE => ItemIds::IRON_INGOT,
                    ItemIds::GOLD_ORE => ItemIds::GOLD_INGOT,
                    ItemIds::COBBLESTONE => ItemIds::STONE,
                    default => 0
                };

                if ($newId !== 0) {
                    $newDrops[$k] = ItemFactory::getInstance()->get($newId, 0, $drop->getCount());
                }
            }

            $event->setDrops($newDrops);
        }
    }

    #[Pure]
    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof BlockBreakEvent;
    }
}