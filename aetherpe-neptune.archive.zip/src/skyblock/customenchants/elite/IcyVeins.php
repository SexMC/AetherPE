<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Living;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\traits\CooldownTrait;

class IcyVeins extends ReactiveEnchant {
    use CooldownTrait;

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_ARMOUR);
        $this->setMaxLevel(3);
        $this->setDescription("A (Level * 2.5)% Chance to cause slowness to your attacker.");

        return new CustomEnchantIdentifier("icy_veins", "Icy Veins", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Living) {
                $damager->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 20*5, 2));
            }

            if ($damager instanceof Player) {
                $this->setCooldown($player, 15);
            }
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent
            && $player->getId() === $event->getEntity()->getId()
            && mt_rand(1, 100) < $enchantInstance->getLevel() * 2.5
            && $event->getDamager() instanceof Player
            && !$this->isOnCooldown($event->getDamager());
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§b** Icy Veins (§r§7Enemy Slowed§l§b) **";
	}
}