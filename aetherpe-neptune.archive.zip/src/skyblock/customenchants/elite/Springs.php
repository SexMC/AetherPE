<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\item\Item;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ToggleableEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class Springs extends ToggleableEnchant {
	public function prepare() : CustomEnchantIdentifier{
		$this->setRarity(Rarity::elite());
		$this->setMaxLevel(3);
		$this->setDescription("Gives jump boost");
		$this->setApplicableTo(self::ITEM_BOOTS);

		return new CustomEnchantIdentifier("springs", "Springs", false);
	}

	function toggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		$player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::JUMP_BOOST(), 20 * 99999, $enchantmentInstance->getLevel() - 1)));
	}

	function unToggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		$player->getEffects()->remove(VanillaEffects::JUMP_BOOST());
	}
}