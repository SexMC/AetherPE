<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\event\Event;
use pocketmine\item\SplashPotion;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Execute extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_SWORD);
        $this->setMaxLevel(5);
        $this->setDescription("A (Level * 4)% Chance to deal massive damage on enemy players with less than 45% HP.");

        return new CustomEnchantIdentifier("execute", "Execute", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $event->getEntity()->setHealth($event->getEntity()->getHealth() - ($dmg =  mt_rand(1, 3)));
				$player->sendMessage("§r§l§b** Execute (§r§7+$dmg Outgoing Damage§l§b) **");

				$this->setCooldown($player, 2);
            }
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && $event->getEntity()->getHealth() <= 8 && mt_rand(1, 100) < $enchantInstance->getLevel() * 4 &&!$this->isOnCooldown($player);
    }
}