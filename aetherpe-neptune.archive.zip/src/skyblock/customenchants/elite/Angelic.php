<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\ItemEditor;
use skyblock\items\itemmods\types\SpaceVisorItemMod;
use skyblock\items\rarity\Rarity;

class Angelic extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_ARMOUR);
        $this->setMaxLevel(5);
        $this->setDescription("A (Level * 2%) Chance to give you the regeneration III effect for 3 seconds.");

        return new CustomEnchantIdentifier("angelic", "Angelic");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        $player->getEffects()->add(new EffectInstance(VanillaEffects::REGENERATION(), 20*3, 2));
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§a** Angelic (§r§7Regeneration III for 3 seconds§l§a)";
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) < $enchantInstance->getLevel();
    }
}