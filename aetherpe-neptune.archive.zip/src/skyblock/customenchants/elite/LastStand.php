<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class LastStand extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_ARMOUR);
        $this->setMaxLevel(4);
        $this->setDescription("A (Level * 5)% Chance to negate 50% of damage from incoming attacks that would normally kill you.");

        return new CustomEnchantIdentifier("last_stand", "Last Stand");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            if ($event->getFinalDamage() > $player->getHealth()) {
                $event->divideDamage(2,'last-stand-damage-divider');
            }
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId() && $event->getFinalDamage() > $player->getHealth() && mt_rand(1, 100) < $enchantInstance->getLevel() * 5;
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§7** Last Stand (§r§7Woah there! that was going to kill you!§l§7) **";
	}
}