<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Grounded extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_ARMOUR);
        $this->setMaxLevel(5);
        $this->setDescription("A (Level * 5)% chance to negate shockwave.");

        return new CustomEnchantIdentifier("grounded", "Grounded");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEnchantsReactionManager) {
            $event->negate(ShockWave::class, self::class);
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		if($event instanceof CustomEntityDamageByEntityEvent && $event->getDamager()->getId() === $player->getId()){
			if(mt_rand(1, 100) < $enchantInstance->getLevel() * 5){
				if(!$event->getEntityCustomEnchantsReactionManager()->isActivating(ShockWave::class)) return false;

				$event->getEntityCustomEnchantsReactionManager()->negate(ShockWave::class, self::class);


				return true;
			}
		}

		return false;
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§6** Grounded (§r§7Blocked Shockwave§l§6) **";
	}
}