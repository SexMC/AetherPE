<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\block\VanillaBlocks;
use pocketmine\event\Event;
use pocketmine\player\Player;
use pocketmine\world\particle\BlockBreakParticle;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class DangerClose extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_SWORD);
        $this->setMaxLevel(5);
        $this->setDescription("The closer you are to an enemy when hitting them, the more damage you will deal (Level * 1.05). However, if you are more than 2.5 blocks away, you will deal LESS damage than normal (Level * 1.05).");

        return new CustomEnchantIdentifier("danger_close", "Danger Close", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            if ($entity->getPosition()->distance($player->getPosition()) < 2.5) {
                $event->multiplyDamage($add = (($enchantInstance->getLevel() * 0.05)), "dangerclose-increase");
				//$add += 1;
				//$player->sendMessage("§r§l§6** Danger Close (§r§7{$add}% Incoming Damage§l§6) **");
				$event->getEntity()->getWorld()->addParticle($event->getEntity()->getLocation(), new BlockBreakParticle(VanillaBlocks::OBSIDIAN()));
			} else {
                $event->divideDamage($add = (1 + ($enchantInstance->getLevel() * 0.05)), "dangerclose-decrease");
				$player->sendMessage("§r§l§6** Danger Close (§r§7-{$add}% Incoming Damage§l§6) **");
            }
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId();
    }
}