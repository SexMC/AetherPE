<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Paralyze extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_AXE);
        $this->setMaxLevel(4);
        $this->setDescription("A (Level * 3)% Chance to give lightning affect as well as to give slowness and slow swinging to the target player, inflicting small damage on proc.");

        return new CustomEnchantIdentifier("paralyze", "Paralyze");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $damager->setHealth($damager->getHealth() - 2);
				$this->setCooldown($player, 20);
            }
        }
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§8** Paralyze (§r§7You gave them Corona Virus§l§8) **";
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) < $enchantInstance->getLevel() * 3 && !$this->isOnCooldown($event->getDamager());
    }
}