<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\item\Item;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ToggleableEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class ObsidianShield extends ToggleableEnchant {
	public function prepare() : CustomEnchantIdentifier{
		$this->setRarity(Rarity::elite());
		$this->setMaxLevel(1);
		$this->setDescription("Gives fire resistance");
		$this->setApplicableTo(self::ITEM_LEGGINGS);

		return new CustomEnchantIdentifier("obsidian_shield", "Obsidian Shield", false);
	}

	function toggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		$player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::FIRE_RESISTANCE(), 20 * 99999, 1)));
	}

	function unToggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		$player->getEffects()->remove(VanillaEffects::FIRE_RESISTANCE());
	}
}