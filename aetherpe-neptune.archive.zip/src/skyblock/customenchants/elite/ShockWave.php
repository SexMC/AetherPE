<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\entity\Living;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class ShockWave extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_ARMOUR);
        $this->setMaxLevel(5);
        $this->setDescription("A (Level * 3)% chance to knockback your attacker.");

        return new CustomEnchantIdentifier("shockwave", "Shockwave");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
			$e = $event->getEntity();
			if(!$e instanceof Living) return;

			$x = mt_rand(15, 20);
			$z = mt_rand(15, 20);
			$e->knockBack((mt_rand(1, 2) === 1 ? $x : -$x), (mt_rand(1, 2) === 1 ? $z : -$z), 2.5, 1.5);
			$this->setCooldown($player, 75);
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() !== $event->getEntity()->getId() && mt_rand(1, 100) < $enchantInstance->getLevel() * 3 && !$this->isOnCooldown($player);
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§b** Shockwave (§r§7I have Corona Virus!§l§b) **";
	}
}