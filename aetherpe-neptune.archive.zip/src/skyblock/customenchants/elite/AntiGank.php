<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use JetBrains\PhpStorm\Pure;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\utils\IslandUtils;

class AntiGank extends ReactiveEnchant {

    private array $hitRecords = [];

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_AXE);
        $this->setMaxLevel(4);
        $this->setDescription("If (6-level) or more enemies hit you in a short period of time, your outgoing damage will be multiplied by up to 1.5x depending (1 + 0.05 * Enemies Nearby). Enemies must be within 6 blocks.");

        return new CustomEnchantIdentifier("anti_gank", "Anti Gank", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        /*if ($event instanceof CustomEntityDamageByEntityEvent) {
            if (!isset($this->hitRecords[$player->getName()])) {
                $this->hitRecords[$player->getName()] = [];
            }

            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $this->hitRecords[$player->getName()] = time();
            }

            foreach ($this->hitRecords[$player->getName()] as $k => $time) {
                if(time() - $time > 5) {
                    unset($this->hitRecords[$player->getName()][$k]);
                }
            }

            if (count($this->hitRecords[$player->getName()]) > 6 - $enchantInstance->getLevel()) {
                $event->multiplyDamage((count(IslandUtils::getNearbyEnemies($player)) / 20), "antigank-enchantment-aggressive-multiplier");
            }
        }*/
    }

    #[Pure]
    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId();
    }
}