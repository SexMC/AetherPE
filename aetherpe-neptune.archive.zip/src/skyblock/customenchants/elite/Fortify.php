<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Fortify extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_ARMOUR);
        $this->setMaxLevel(5);
        $this->setDescription("Increase damage related Armor Attribute passives.");

        return new CustomEnchantIdentifier("fortify", "Fortify", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        //not required by any passives yet
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId();
    }
}