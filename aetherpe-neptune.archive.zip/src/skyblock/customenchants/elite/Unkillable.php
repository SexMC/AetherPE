<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Unkillable extends ReactiveEnchant {

    const UNKILLABLE_ACTIVATION_COOLDOWN_ID = 0;

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_HELMET);
        $this->setMaxLevel(3);
        $this->setDescription("Attacks that bring your HP to (level+4) hearts or lower have a chance to heal you for (level+5) hearts instead. (60s Cool-down)");

        return new CustomEnchantIdentifier("unkillable", "Unkillable");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $player->setHealth(min($player->getMaxHealth(), $player->getHealth() + $enchantInstance->getLevel() + 5));
			$this->setCooldown($player, 60);
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId() && $player->getHealth() - $event->getFinalDamage() < $enchantInstance->getLevel() + 4 && !$this->isOnCooldown($player);
    }
}