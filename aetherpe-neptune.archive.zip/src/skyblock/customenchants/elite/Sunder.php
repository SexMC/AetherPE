<?php

declare(strict_types=1);

namespace skyblock\customenchants\elite;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Sunder extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::elite());
        $this->setApplicableTo(self::ITEM_WEAPONS);
        $this->setMaxLevel(4);
        $this->setDescription("A (Level * 3)% chance to bypass Enemy Armor Attributes when dealing Outgoing DMG.");

        return new CustomEnchantIdentifier("sunder", "Sunder");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            //TODO: not gonna implement I guess?
			$this->setCooldown($player, 30);
        }
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§e** Sunder (§r§7Hit Bypassed Enemy Armor Set Defence§l§e) **";
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) < $enchantInstance->getLevel() * 3 && !$this->isOnCooldown($player);
    }
}