<?php

declare(strict_types=1);

namespace skyblock\customenchants\heroic;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\legendary\Deathbringer;
use skyblock\customenchants\legendary\Overload;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class DominationDeathbringer extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::heroic());
		$this->setMaxLevel(3);
		$this->setDescription("Chance to deal triple damage, lower proc rates");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("domination_deathbringer", "Domination Deathbringer");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$this->setCooldown($player, 20);
			$event->multiplyDamage(3, "domination_deathbringer");

			$ce = CustomEnchantHandler::getCustomEnchantByName("Triple Sweeping Strike");
			if($ce instanceof ReactiveEnchant){
				$ce->setCooldown($player, 45);
			}
		}
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§d** Domination Deathbringer (§r§7+300% Damage§l§d) **";
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(0, 100) <= $enchantInstance->getLevel() - 1 && !$this->isOnCooldown($player);
	}

	public function getChildEnchantmentId() : string{
		return CustomEnchantHandler::getIdByClass(Deathbringer::class);
	}
}