<?php

declare(strict_types=1);

namespace skyblock\customenchants\heroic;

use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\legendary\Inquisitive;
use skyblock\customenchants\legendary\Overload;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\Mob;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class ApaceInquisitive extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([EntityDeathEvent::class]);
		$this->setRarity(Rarity::heroic());
		$this->setMaxLevel(5);
		$this->setDescription("Double the XP you get with inquisitive.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("apace_inquisitive", "Apace Inquisitive", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof EntityDeathEvent){
			$event->setXpDropAmount((int) ($event->getXpDropAmount() * (1 + (0.65 * $enchantInstance->getLevel()))));
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof EntityDeathEvent && $event->getEntity() instanceof Mob;
	}


	public function getChildEnchantmentId() : string{
		return CustomEnchantHandler::getIdByClass(Inquisitive::class);
	}
}