<?php

declare(strict_types=1);

namespace skyblock\customenchants\heroic;


use pocketmine\event\Event;
use pocketmine\item\Sword;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacketV1;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use pocketmine\player\Player;
use pocketmine\world\sound\ClickSound;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\rare\AntiSword;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\LightningEntity;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\utils\EntityUtils;

class IronHideAntiSword extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::heroic());
		$this->setMaxLevel(4);
		$this->setDescription("Same as regular Anti Sword but decreases damage more");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("iron_hide_anti_sword", "Iron-Hide Anti Sword", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$divide = 0.050 * $enchantInstance->getLevel();

			$event->divideDamage($divide, "iron_hide_anti_sword");
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$damager = $event->getDamager();

			if($damager instanceof Player && $player->getId() === $event->getEntity()->getId()){
				if($damager->getInventory()->getItemInHand() instanceof Sword){
					return true;
				}
			}
		}

		return false;
	}

	public function getChildEnchantmentId() : string{
		return CustomEnchantHandler::getIdByClass(AntiSword::class);
	}
}