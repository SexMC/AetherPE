<?php

declare(strict_types=1);

namespace skyblock\customenchants\heroic;


use pocketmine\event\Event;
use pocketmine\item\Axe;
use pocketmine\item\Sword;
use pocketmine\network\mcpe\protocol\LevelEventPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacketV1;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use pocketmine\player\Player;
use pocketmine\world\sound\ClickSound;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\rare\AntiAxe;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\LightningEntity;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\utils\EntityUtils;

class ForceFieldAntiAxe extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::heroic());
		$this->setMaxLevel(4);
		$this->setDescription("Same as regular Anti Axe but decreases damage more");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("force_field_anti_axe", "Force-Field Anti Axe", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$divide = 0.050 * $enchantInstance->getLevel();

			$event->divideDamage($divide, "force_field_anti_axe");
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$damager = $event->getDamager();

			if($damager instanceof Player && $player->getId() === $event->getEntity()->getId()){
				if($damager->getInventory()->getItemInHand() instanceof Axe){
					return true;
				}
			}
		}

		return false;
	}

	public function getChildEnchantmentId() : string{
		return CustomEnchantHandler::getIdByClass(AntiAxe::class);
	}
}