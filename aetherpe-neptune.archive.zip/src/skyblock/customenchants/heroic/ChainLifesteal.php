<?php

declare(strict_types=1);

namespace skyblock\customenchants\heroic;

use pocketmine\block\VanillaBlocks;
use pocketmine\event\Event;
use pocketmine\player\Player;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\world\sound\BlockBreakSound;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\legendary\Lifesteal;
use skyblock\customenchants\legendary\Overload;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;
use skyblock\utils\EntityUtils;

class ChainLifesteal extends ReactiveEnchant{


	public function prepare() : CustomEnchantIdentifier{
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::mastery());
		$this->setMaxLevel(5);
		$this->setDescription("A chance to regain health from multiple players near your damaged target based on level..");
		$this->setApplicableTo(self::ITEM_HELMET);

		return new CustomEnchantIdentifier("chain_lifesteal", "Chain Lifesteal", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : void{
		if($event instanceof CustomEntityDamageByEntityEvent){
			$this->setCooldown($player, 35);

			$level = $enchantInstance->getLevel();
			$session = new Session($player);
			$members = [];

			if(($is = $session->getIslandName()) !== null){
				$island = new Island($is);
				$members = array_merge($island->getMembers(), [$island->getLeader()]);
			}

			$total = 0;

			foreach ($player->getWorld()->getNearbyEntities($player->getBoundingBox()->expandedCopy($level, $level, $level), $player) as $entity) {
				if (!$entity instanceof Player) {
					return;
				}

				if (in_array($entity->getName(), $members)) {
					continue;
				}

				$entity->setHealth($entity->getHealth() - ($took = ($enchantInstance->getLevel() / 2)));
				$entity->getNetworkSession()->sendDataPacket(EntityUtils::getSoundPacket("mob.enderdragon.flap", $player->getLocation()));

				$total += $took;
			}

			$player->setHealth($player->getHealth() + $total);
			$player->sendMessage("§r§l§4** Chain Lifesteal (§r§7+$total HP§l§4) **");
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : bool{
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 125) <= $enchantInstance->getLevel() * 2 && !$this->isOnCooldown($player);
	}
}