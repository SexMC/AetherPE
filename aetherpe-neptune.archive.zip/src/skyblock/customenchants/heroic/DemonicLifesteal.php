<?php

declare(strict_types=1);

namespace skyblock\customenchants\heroic;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\legendary\Lifesteal;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class DemonicLifesteal extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::heroic());
		$this->setMaxLevel(5);
		$this->setDescription("A chance to siphon a lot of HP from your target.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("demonic_lifesteal", "Demonic Lifesteal");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$event->getEntity()->setHealth($event->getEntity()->getHealth() - ($enchantInstance->getLevel() + 1));
			$player->setHealth($player->getHealth() + ($enchantInstance->getLevel() + 1));
			$this->setCooldown($player, 60);
		}
	}

	public function getChildEnchantmentId() : string{
		return CustomEnchantHandler::getIdByClass(Lifesteal::class);
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel() * 2 && !$this->isOnCooldown($player) && !$this->isOnCooldown($player);
	}
}