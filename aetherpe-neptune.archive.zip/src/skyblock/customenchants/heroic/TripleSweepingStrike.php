<?php

declare(strict_types=1);

namespace skyblock\customenchants\heroic;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\customenchants\CustomEnchant;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\legendary\DoubleStrike;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class TripleSweepingStrike extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::heroic());
		$this->setMaxLevel(3);
		$this->setDescription("Chance to strike your enemy three times.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("triple_sweeping_strike", "Triple Sweeping Strike");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$event->multiplyDamage(3, "Triple Sweeping Strike");

			$ce = CustomEnchantHandler::getCustomEnchantByName("Domination Deathbringer");
			if($ce instanceof ReactiveEnchant){
				$ce->setCooldown($player, 45);
			}
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(0, 100) <= ($enchantInstance->getLevel() - 1);
	}

	public function getChildEnchantmentId() : string{
		return CustomEnchantHandler::getIdByClass(DoubleStrike::class);
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§d** Triple Sweeping Strike (§r§7You struck him thrice§l§d) **";
	}
}