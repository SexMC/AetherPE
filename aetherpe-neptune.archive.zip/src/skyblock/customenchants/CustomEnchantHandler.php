<?php

declare(strict_types=1);

namespace skyblock\customenchants;

use skyblock\customenchants\elite\Angelic;
use skyblock\customenchants\elite\AntiGank;
use skyblock\customenchants\elite\Aquatic;
use skyblock\customenchants\elite\AutoSmelt;
use skyblock\customenchants\elite\DangerClose;
use skyblock\customenchants\elite\Execute;
use skyblock\customenchants\elite\Fortify;
use skyblock\customenchants\elite\Grounded;
use skyblock\customenchants\elite\IcyVeins;
use skyblock\customenchants\elite\LastStand;
use skyblock\customenchants\elite\ObsidianShield;
use skyblock\customenchants\elite\Paralyze;
use skyblock\customenchants\elite\ShockWave;
use skyblock\customenchants\elite\Spiked;
use skyblock\customenchants\elite\Sunder;
use skyblock\customenchants\elite\Trap;
use skyblock\customenchants\elite\Unkillable;
use skyblock\customenchants\heroic\DemonicLifesteal;
use skyblock\customenchants\heroic\EternalLuck;
use skyblock\customenchants\heroic\ExtremeOverload;
use skyblock\customenchants\legendary\FullyBelly;
use skyblock\customenchants\legendary\Luck;
use skyblock\customenchants\legendary\Drunk;
use skyblock\customenchants\mastery\AbyssalWrath;
use skyblock\customenchants\heroic\ApaceInquisitive;
use skyblock\customenchants\heroic\BrightEnlighted;
use skyblock\customenchants\heroic\ChainLifesteal;
use skyblock\customenchants\heroic\DominationDeathbringer;
use skyblock\customenchants\mastery\Infectious;
use skyblock\customenchants\mastery\MindRot;
use skyblock\customenchants\mastery\MobAura;
use skyblock\customenchants\legendary\Overload;
use skyblock\customenchants\heroic\TripleSweepingStrike;
use skyblock\customenchants\legendary\Vengeance;
use skyblock\customenchants\mastery\Rage;
use skyblock\customenchants\rare\AdrenalineRush;
use skyblock\customenchants\rare\AntiAxe;
use skyblock\customenchants\rare\AntiSword;
use skyblock\customenchants\rare\Blacksmith;
use skyblock\customenchants\rare\Blessed;
use skyblock\customenchants\legendary\Clarity;
use skyblock\customenchants\rare\Cleave;
use skyblock\customenchants\rare\Dodge;
use skyblock\customenchants\rare\Dominate;
use skyblock\customenchants\legendary\DustFinder;
use skyblock\customenchants\rare\Electrify;
use skyblock\customenchants\heroic\ExtremeFanatic;
use skyblock\customenchants\rare\Fanatic;
use skyblock\customenchants\heroic\ForceFieldAntiAxe;
use skyblock\customenchants\rare\Gears;
use skyblock\customenchants\rare\Haste;
use skyblock\customenchants\heroic\IronHideAntiSword;
use skyblock\customenchants\rare\Metaphysical;
use skyblock\customenchants\heroic\MightyCleave;
use skyblock\customenchants\rare\MoneyMiner;
use skyblock\customenchants\rare\OreMagnet;
use skyblock\customenchants\legendary\ScriptureFinder;
use skyblock\customenchants\rare\Silence;
use skyblock\customenchants\legendary\XPDiscovery;
use skyblock\customenchants\elite\Springs;
use skyblock\customenchants\uncommon\Berserk;
use skyblock\customenchants\legendary\Deathbringer;
use skyblock\customenchants\legendary\DoubleStrike;
use skyblock\customenchants\legendary\Enlighted;
use skyblock\customenchants\uncommon\Experience;
use skyblock\customenchants\uncommon\FastSwing;
use skyblock\customenchants\uncommon\Fatigue;
use skyblock\customenchants\uncommon\Headless;
use skyblock\customenchants\legendary\Inquisitive;
use skyblock\customenchants\uncommon\LifeBloom;
use skyblock\customenchants\legendary\Lifesteal;
use skyblock\customenchants\uncommon\LightForged;
use skyblock\customenchants\uncommon\Molten;
use skyblock\customenchants\uncommon\PlagueCarrier;
use skyblock\customenchants\uncommon\Reforged;
use skyblock\customenchants\uncommon\WellFed;

class CustomEnchantHandler {
	
	private static array $customEnchants = [
		ICustomEnchant::RARITY_UNCOMMON => [],
		ICustomEnchant::RARITY_ELITE => [],
		ICustomEnchant::RARITY_LEGENDARY => [],
		ICustomEnchant::RARITY_RARE => [],
		ICustomEnchant::RARITY_MASTERY => [],
		ICustomEnchant::RARITY_ESSENCE => [],
	];

	private static array $rawCustomEnchants = [];

	private static array $customEnchantsByName = [];

	private static array $classById = [];


	public function __construct(){
		foreach(self::getAll() as $ce){
			self::$classById[$ce::class] = $ce->getIdentifier()->getId();
			self::$customEnchants[$ce->getRarity()->getTier()][] = $ce;
			self::$rawCustomEnchants[$ce->getIdentifier()->getId()] = $ce;
			self::$customEnchantsByName[strtolower($ce->getIdentifier()->getName())] = $ce;
		}
	}

	public static function getCustomEnchantById(string $id): ?CustomEnchant {
		return self::$rawCustomEnchants[$id] ?? null;
	}

	public static function getCustomEnchantByName(string $name): ?CustomEnchant {
		return self::$customEnchantsByName[strtolower($name)] ?? null;
	}

	public static function getCustomEnchantsByRarity(int $rarity): array {
		return self::$customEnchants[$rarity] ?? [];
	}

	public static function getIdByClass(string $class) : ?string{
		return self::$classById[$class] ?? null;
	}

	/**
	 * @return CustomEnchant[]
	 */
	public static function getAllCustomEnchantsByName(): array {
		return self::$customEnchantsByName;
	}


	/**
	 * @return CustomEnchant[]
	 */
	private static function getAll(): array{
		return [
			//uncommon
			new Berserk(),
			new Experience(),
			new FastSwing(),
			new Fatigue(),
			new Headless(),
			new LifeBloom(),
			new LightForged(),
			new Molten(),
			new PlagueCarrier(),
			//new Reforged(),
			new WellFed(),

			//elite
			new Unkillable(),
			new Trap(),
			new Sunder(),
			new Spiked(),
			new ShockWave(),
			new Paralyze(),
			new LastStand(),
			new IcyVeins(),
			new Grounded(),
			new Fortify(),
			new Execute(),
			new DangerClose(),
			new AutoSmelt(),
			new AntiGank(),
			new Angelic(),

			//legendary
			new Deathbringer(),
			new Enlighted(),
			new DoubleStrike(),
			new Lifesteal(),
			new Inquisitive(),
			new Overload(),
			new XPDiscovery(),
			new Vengeance(),
			new DustFinder(),
			new ScriptureFinder(),
			new FullyBelly(),

			//rare
			new AdrenalineRush(),
			new Electrify(),
			new Dodge(),
			new Haste(),
			new Metaphysical(),
			new OreMagnet(),
			new MoneyMiner(),
			new Fanatic(),
			new Dominate(),
			new Blacksmith(),
			new Silence(),
			new Cleave(),
			new ExtremeOverload(),
			new Gears(),

			//heroic
			new ChainLifesteal(),
			new ApaceInquisitive(),
			new MightyCleave(),
			new ExtremeFanatic(),
			new TripleSweepingStrike(),
			new DominationDeathbringer(),
			new BrightEnlighted(),
			new ForceFieldAntiAxe(),
			new IronHideAntiSword(),
			new AntiSword(),
			new AntiAxe(),

			//mastery
			new MobAura(),
			new AbyssalWrath(),
			new Rage(),
			new Infectious(),
            new MindRot(),

			new Drunk(),
			new Blessed(),
			new Springs(),
			new Clarity(),
			new Luck(),
			new EternalLuck(),
			new ObsidianShield(),

			new Aquatic(),
			new DemonicLifesteal(),
		];
	}
}