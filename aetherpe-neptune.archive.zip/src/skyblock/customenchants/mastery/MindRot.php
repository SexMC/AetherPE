<?php

declare(strict_types=1);

namespace skyblock\customenchants\mastery;

use JetBrains\PhpStorm\Pure;
use pocketmine\entity\Entity;
use pocketmine\entity\Living;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\traits\CooldownTrait;

class MindRot extends ReactiveEnchant {
    use CooldownTrait;

    private array $tagged = [];

    public function prepare() : CustomEnchantIdentifier{
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::mastery());
        $this->setMaxLevel(6);
        $this->setDescription("Chance to mark the enemy with Mind Rot, while marked all incoming damage will be increased. (A player can only be marked once every 5s)");
        $this->setApplicableTo(self::ITEM_WEAPONS);

        return new CustomEnchantIdentifier("mind_rot", "Mind Rot", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : void{
        if($event instanceof CustomEntityDamageByEntityEvent){
            $entity = $event->getEntity();
            if ($this->isTagged($entity) && $this->isOnCooldown($entity)) {
                $event->multiplyDamage(($enchantInstance->getLevel() * 0.1), "mind_rot_multiplier");
            } elseif ($entity instanceof Living && (!$entity instanceof Player || !$this->isOnCooldown($entity))) {
                $player->sendMessage("§l§4** MindRot (§r§7+" . $enchantInstance->getLevel() * 10 . "% Damage to {$entity->getName()} [5s]§l§4) **§r");
                if ($entity instanceof Player) {
                    $entity->sendMessage("§l§4** MindRot (§r§7+" . $enchantInstance->getLevel() * 10 . "% Damage from {$player->getName()} [5s]§l§4) **§r");
                }
                $this->setCooldown($entity, 5);
                $this->setTagged($entity);
            }
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : bool{
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(0, 100) < 5;
    }

    public function setTagged(Entity $entity): void {
        $this->tagged[] = $entity->getId();
    }

    public function removeTagged(Entity $entity): void {
        unset($this->tagged[array_search($entity->getId(), $this->tagged)]);
    }

    #[Pure]
    public function isTagged(Entity $entity): bool {
        return in_array($entity->getId(), $this->tagged);
    }
}