<?php

declare(strict_types=1);

namespace skyblock\customenchants\mastery;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\Mob;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class MobAura extends ReactiveEnchant{

	public function prepare() : CustomEnchantIdentifier{
		$this->setEvents([EntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::mastery());
		$this->setMaxLevel(4);
		$this->setDescription("Chance to kill multiple mobs in a stack (at max level kill 24 mobs at once)");
		$this->setApplicableTo(self::ITEM_AXE);

		return new CustomEnchantIdentifier("mob_aura", "Mob Aura");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : void{
		if($event instanceof EntityDamageByEntityEvent){
			$entity = $event->getEntity();


			if($entity instanceof Mob){
				$amount = mt_rand($enchantInstance->getLevel(), $enchantInstance->getLevel() * 6);
				for($i = 1; $i <= $amount; $i++){
					$entity->kill();
					$entity->setLastDamageCause($event);
				}
			}
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : bool{
		return $event instanceof EntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && $event->getEntity() instanceof Mob && mt_rand(1, 75) <= $enchantInstance->getLevel();
	}
}