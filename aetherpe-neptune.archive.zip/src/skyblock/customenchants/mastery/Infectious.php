<?php

declare(strict_types=1);

namespace skyblock\customenchants\mastery;

use pocketmine\block\VanillaBlocks;
use pocketmine\entity\animation\HurtAnimation;
use pocketmine\event\Event;
use pocketmine\network\mcpe\protocol\ActorEventPacket;
use pocketmine\network\mcpe\protocol\types\ActorEvent;
use pocketmine\player\Player;
use pocketmine\world\particle\BlockBreakParticle;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\traits\AwaitStdTrait;
use skyblock\utils\Utils;
use SOFe\AwaitGenerator\Await;

class Infectious extends ReactiveEnchant{
	use AwaitStdTrait;

	public function prepare() : CustomEnchantIdentifier{
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::mastery());
		$this->setMaxLevel(3);
		$this->setDescription("A chance to spread a deadly infection when damaged.");
		$this->setApplicableTo(self::ITEM_CHESTPLATE);

		return new CustomEnchantIdentifier("infectious", "Infectious");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : void{
		if($event instanceof CustomEntityDamageByEntityEvent){
			$this->setCooldown($player, 60);

			$level = $enchantInstance->getLevel();
			foreach($player->getWorld()->getNearbyEntities($player->getBoundingBox()->expandedCopy(4 + $level, 4 + $level, 4 + $level)) as $entity){
				if($entity instanceof Player && !$this->isOnCooldown($entity)){
					$this->setCooldown($entity, 60);
					Await::f2c(function() use($entity, $level) {
						for($i = 0; $i <= $level; $i++){
							if($entity->isOnline()){
								$entity->broadcastAnimation(new HurtAnimation($entity));
								$entity->setHealth($entity->getHealth() - min(2, $level));
								$entity->getWorld()->addParticle($entity->getLocation(), new BlockBreakParticle(VanillaBlocks::REDSTONE()));
								$entity->sendTip($this->getActivateMessage($entity));

								yield $this->getStd()->sleep(20);
							}
						}
					});
				}
			}
		}
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§4** Infectious (§r§7-1 TRUE DAMAGE§l§4) §l§4**";
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : bool{
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId() && $event->getEntity() instanceof Player && mt_rand(1, 100) <= $enchantInstance->getLevel() && !$this->isOnCooldown($event->getEntity());
	}
}