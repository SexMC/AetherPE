<?php

declare(strict_types=1);

namespace skyblock\customenchants\mastery;

use pocketmine\block\VanillaBlocks;
use pocketmine\event\Event;
use pocketmine\player\Player;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\world\sound\BlockBreakSound;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\Mob;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\Main;
use skyblock\sessions\Session;
use skyblock\traits\AwaitStdTrait;
use skyblock\utils\EntityUtils;
use skyblock\utils\Utils;
use SOFe\AwaitGenerator\Await;
use SOFe\AwaitStd\AwaitStd;

class AbyssalWrath extends ReactiveEnchant{
	use AwaitStdTrait;

	public function prepare() : CustomEnchantIdentifier{
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::mastery());
		$this->setMaxLevel(4);
		$this->setDescription("Temporarily freeze all nearby enemies, pushing them away and causing wrath damage.");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("abyssal_wrath", "Abyssal Wrath");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : void{
		if($event instanceof CustomEntityDamageByEntityEvent){
			$this->setCooldown($player, 75);

			$level = $enchantInstance->getLevel() + 5;
			$session = new Session($player);
			$members = [];

			if(($is = $session->getIslandName()) !== null){
				$island = new Island($is);
				$members = array_merge($island->getMembers(), [$island->getLeader()]);
			}

			foreach ($player->getWorld()->getNearbyEntities($player->getBoundingBox()->expandedCopy($level, $level, $level), $player) as $entity) {
				if (!$entity instanceof Player) {
					continue;
				}

				if (in_array($entity->getName(), $members)) {
					continue;
				}

				$x = mt_rand(15, 20);
				$z = mt_rand(15, 20);
				$entity->knockBack((mt_rand(1, 2) === 1 ? $x : -$x), (mt_rand(1, 2) === 1 ? $z : -$z), 2, 1);
				$entity->setHealth($entity->getHealth() - ($enchantInstance->getLevel()));
				$entity->sendMessage("§r§l§c** Abyssal Wrath (§r§7Feel my Power!§l§c) **");

				Await::f2c(function() use($entity) {
					yield Main::getInstance()->getStd()->sleep(25);
					$entity->setImmobile();


					if($entity->isOnline()){
						$entity->setImmobile();

						yield Main::getInstance()->getStd()->sleep(40);

						if($entity->isOnline()){
							$entity->setImmobile(false);
						}
					}
				});
			}
			$player->getWorld()->broadcastPacketToViewers($player->getLocation(), EntityUtils::getSoundPacket("mob.enderdragon.growl", $player->getLocation(), 3));
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : bool{
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId() && $event->getDamager() instanceof Player && mt_rand(1, 100) <= $enchantInstance->getLevel() && !$this->isOnCooldown($player);
	}
}