<?php

declare(strict_types=1);

namespace skyblock\customenchants\mastery;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\Mob;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Rage extends ReactiveEnchant{

	private static array $stack = [];

	public function prepare() : CustomEnchantIdentifier{
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::mastery());
		$this->setMaxLevel(6);
		$this->setDescription("For every combo hit you land, your damage is increased by 10% (max 50%)");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("rage", "Rage", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : void{
		if($event instanceof CustomEntityDamageByEntityEvent){
			$entity = $event->getEntity();
			$damager = $event->getDamager();

			if($entity->getId() === $player->getId()){
				self::setStack($player, 0);
				$player->sendTip($this->getRarity()->getColor() . $this->getIdentifier()->getName() . "\n§c§lRESET");
			}

			if($damager->getId() === $player->getId()){
				self::setStack($player, $all = (min(5, ($stack = (self::getStack($player) + 1)))));
				$player->sendTip($this->getRarity()->getColor() . $this->getIdentifier()->getName() . "\n§a§l" . $all * 10 . "%%");
				$event->multiplyDamage($stack / 10, "rage");
			}
		}
	}

	public function setStack(Player $player, int $amount): void {
		self::$stack[$player->getName()] = $amount;
	}

	public function getStack(Player $player): int {
		return self::$stack[$player->getName()] ?? 0;
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : bool{
		return $event instanceof CustomEntityDamageByEntityEvent;
	}
}