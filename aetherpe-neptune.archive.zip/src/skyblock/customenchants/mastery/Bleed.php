<?php

declare(strict_types=1);

namespace skyblock\customenchants\mastery;

use pocketmine\block\VanillaBlocks;
use pocketmine\event\Event;
use pocketmine\network\mcpe\protocol\ActorEventPacket;
use pocketmine\network\mcpe\protocol\types\ActorEvent;
use pocketmine\player\Player;
use pocketmine\world\particle\BlockBreakParticle;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\utils\Utils;

class Bleed extends ReactiveEnchant{

	public function prepare() : CustomEnchantIdentifier{
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::mastery());
		$this->setMaxLevel(6);
		$this->setDescription("A chance to inflict enemy players with Bleed.");
		$this->setApplicableTo(self::ITEM_AXE);

		return new CustomEnchantIdentifier("bleed", "Bleed");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : void{
		if($event instanceof CustomEntityDamageByEntityEvent){
			$entity = $event->getEntity();

			if($entity instanceof Player){
				$this->setCooldown($entity, 25);

				Utils::executeRepeatedlyFor(function() use ($entity, $player, $event) : void{
					$pk = ActorEventPacket::create($entity->getId(), ActorEvent::HURT_ANIMATION, 0);
					$entity->getWorld()->broadcastPacketToViewers($entity->getLocation(), $pk);
					$entity->getWorld()->addParticle($entity->getLocation(), new BlockBreakParticle(VanillaBlocks::REDSTONE()));

					$entity->setHealth($entity->getHealth() - mt_rand(2, 4));
				}, 20, 0, 7);
			}
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance) : bool{
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && $event->getEntity() instanceof Player && mt_rand(1, 100) <= $enchantInstance->getLevel() && !$this->isOnCooldown($event->getEntity());
	}
}