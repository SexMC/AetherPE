<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Event;
use pocketmine\item\Tool;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\items\rarity\Rarity;

class Reforged extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([BlockBreakEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(10);
        $this->setDescription("Protects tool durability, items will take longer to break.");
        $this->setApplicableTo(self::ITEM_TOOLS);

        return new CustomEnchantIdentifier("reforged", "Reforged");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        $item = $enchantInstance->getItem();

        if ($item instanceof Tool) {
            $item->setDamage(min($item->getDamage() + $enchantInstance->getLevel(), $item->getMaxDurability()));
            $player->getInventory()->setItemInHand($item);
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof BlockBreakEvent && mt_rand(1, 100) < $enchantInstance->getLevel();
    }
}