<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\items\rarity\Rarity;

class Experience extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([BlockBreakEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(5);
        $this->setDescription("Increased XP gain by (10% * level) when mining.");
        $this->setApplicableTo(self::ITEM_PICKAXE);

        return new CustomEnchantIdentifier("experience", "Experience", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof BlockBreakEvent){
			$event->setXpDropAmount((int) ($event->getXpDropAmount() + ($event->getXpDropAmount() * ($enchantInstance->getLevel() / 10))));
		}
	}

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof BlockBreakEvent;
    }
}