<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Living;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class Fatigue extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(5);
        $this->setDescription("A (Level * 3)% to give slowness, mining fatigue and nausea all at level III to players.");
        $this->setApplicableTo(self::ITEM_SWORD);

        return new CustomEnchantIdentifier("fatigue", "Fatigue");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $entity = $event->getEntity();

            if ($entity instanceof Living) {
                $entity->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 20*5, 2));
                $entity->getEffects()->add(new EffectInstance(VanillaEffects::MINING_FATIGUE(), 20*5, 2));
                $entity->getEffects()->add(new EffectInstance(VanillaEffects::NAUSEA(), 20*5, 2));
				$this->setCooldown($player, 40);
            }
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) < $enchantInstance->getLevel() * 3 && !$this->isOnCooldown($player);
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§7** Fatigue (§r§7This activated§l§7) **";
	}
}