<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class LifeBloom extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([PlayerDeathEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(5);
        $this->setDescription("Completely heals allies and truces on death in a (level * 10) block radius.");
        $this->setApplicableTo(self::ITEM_ARMOUR);

        return new CustomEnchantIdentifier("life_bloom", "Life Bloom");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        $session = new Session($player->getName());

        if ($session->getIslandName() !== null) {
            $island = new Island($session->getIslandName());
            $island->getOnlineMembers();

            foreach ($island->getOnlineMembers() as $member) {
                $p = Server::getInstance()->getPlayerExact($member);
                if ($p instanceof Player && $p->getPosition()->distance($player->getPosition()) < $enchantInstance->getLevel() * 10) {
                    $p->setHealth($p->getMaxHealth());
                    $p->sendMessage("§r§l§c** Life Bloom (§r§7+999 HP, {$player->getName()} died§l§c) **");
                }
            }}
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof PlayerDeathEvent && $player === $event->getPlayer();
    }
}