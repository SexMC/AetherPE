<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class PlagueCarrier extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(8);
        $this->setDescription("When near death debuffs nearby enemies to avenge you.");
        $this->setApplicableTo(self::ITEM_ARMOUR);

        return new CustomEnchantIdentifier("plague_carrier", "Plague Carrier");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
			$this->setCooldown($player, 45);
            foreach($player->getWorld()->getNearbyEntities($player->getBoundingBox()->expandedCopy(6, 6, 6)) as $e){
				if($e instanceof Player && $e->getId() !== $player->getId()){
					$e->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 60, 1));
					$e->getEffects()->add(new EffectInstance(VanillaEffects::BLINDNESS(), 60, 1));
					$e->getEffects()->add(new EffectInstance(VanillaEffects::POISON(), 60, 1));
				}
			}
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && !$this->isOnCooldown($player) && $player->getId() === $event->getEntity()->getId() && $player->getHealth() < 4;
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§a** Plague Carrier (§r§7Woah there! that was pretty close§l§a) **";
	}
}