<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;

class Berserk extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(5);
        $this->setDescription("A chance to get a burst of strength (1*Level) for 5 seconds.");
        $this->setApplicableTo(self::ITEM_AXE);

        return new CustomEnchantIdentifier("berserk", "Berserk");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        $player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::STRENGTH(), 20*5, $enchantInstance->getLevel() - 1)));
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 30) <= $enchantInstance->getLevel();
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§a** Berserk (§r§7Burst of Strength§l§a) **";
	}
}