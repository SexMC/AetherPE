<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class FastSwing extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(3);
        $this->setDescription("A (Level * 5)% chance to give a burst of haste III.");
        $this->setApplicableTo(self::ITEM_SWORD);

        return new CustomEnchantIdentifier("fast_swing", "Fast Swing");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        $player->getEffects()->add(new EffectInstance(VanillaEffects::HASTE(), 20*5, 2));
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && mt_rand(1, 100) <= $enchantInstance->getLevel() * 5;
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§7** Fast Swing (§r§7Burst of Haste§l§7) **";
	}
}