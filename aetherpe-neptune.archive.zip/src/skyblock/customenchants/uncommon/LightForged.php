<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;

class LightForged extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(4);
        $this->setDescription("A (Level * 3)% Chance to take 4x durability loss but heal for 1 HP when taking damage.");
        $this->setApplicableTo(self::ITEM_LEGGINGS);

        return new CustomEnchantIdentifier("light_forged", "Light Forged", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $player->damageArmor(3);
            $player->setHealth(min($player->getHealth() + 1, $player->getMaxHealth()));

			$player->sendMessage("§r§l§f** Light Forged (§r§7+1 HP, -4x Durability Leggings§l§f) **");
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getEntity()->getId() && mt_rand(1, 100) < $enchantInstance->getLevel();
    }


}