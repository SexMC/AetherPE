<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\items\rarity\Rarity;
use skyblock\items\special\types\PlayerSkullItem;

class Headless extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([PlayerDeathEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(3);
        $this->setDescription("A (Level * 5)% Chance to loot your victims head on death.");
        $this->setApplicableTo(self::ITEM_WEAPONS);

        return new CustomEnchantIdentifier("headless", "Headless", false);
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof PlayerDeathEvent) {
			$ev = $event->getPlayer()->getLastDamageCause();
			if($ev instanceof EntityDamageByEntityEvent){
				$damager = $ev->getDamager();
				if($damager instanceof Player && $ev->getEntity() instanceof Player){
					$damager->sendMessage("§r§l§8** Headless (§r§7{$ev->getEntity()->getName()}'s Head Dropped§l§8) **");
					$event->setDrops(array_merge($event->getDrops(), [PlayerSkullItem::getItem($ev->getEntity()->getName(), $damager->getName(), $damager->getInventory()->getItemInHand()->getName())]));
				}
			}
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof PlayerDeathEvent && $player !== $event->getPlayer() && mt_rand(1, 100) < $enchantInstance->getLevel() * 5;
    }
}