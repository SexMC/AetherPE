<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\item\Food;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\items\rarity\Rarity;

class WellFed extends ReactiveEnchant {

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([PlayerItemConsumeEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(3);
        $this->setDescription("Replenishes (Level * 3) hunger every time you consume something.");
        $this->setApplicableTo(self::ITEM_ARMOUR);

        return new CustomEnchantIdentifier("well_fed", "Well Fed");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof PlayerItemConsumeEvent) {
            $item = $event->getItem();
            if ($item instanceof Food) {
                $player->getHungerManager()->addFood($enchantInstance->getLevel() * 3);
				$player->getHungerManager()->setSaturation(20);
            }
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof PlayerItemConsumeEvent;
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§7** Well Fed (§r§7Bonus Hunger§l§7) **";
	}
}