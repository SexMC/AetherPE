<?php

declare(strict_types=1);

namespace skyblock\customenchants\uncommon;

use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\items\rarity\Rarity;


class Molten extends ReactiveEnchant {

    public const COOLDOWN_MOLTEN = 0;

    public function prepare(): CustomEnchantIdentifier {
        $this->setEvents([CustomEntityDamageByEntityEvent::class]);
        $this->setRarity(Rarity::uncommon());
        $this->setMaxLevel(3);
        $this->setDescription("A (Level * 3)% Chance to set your attacker on fire for 3 seconds.");
        $this->setApplicableTo(self::ITEM_ARMOUR);

        return new CustomEnchantIdentifier("molten", "Molten");
    }

    public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
        if ($event instanceof CustomEntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            $damager->setOnFire(3);
            $this->setCooldown($player, 15);
        }
    }

    public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
        return $event instanceof CustomEntityDamageByEntityEvent && !$this->isOnCooldown($player) && $player->getId() === $event->getEntity()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel() * 3;
    }

	public function getActivateMessage(Player $player) : string{
		return "§r§l§c** Molten (§r§7ROFL! That person is on FIRE!§l§c) **";
	}
}