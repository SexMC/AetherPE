<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantHandler;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\heroic\ApaceInquisitive;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\entity\Mob;
use skyblock\items\ItemEditor;
use skyblock\items\rarity\Rarity;

class Inquisitive extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([EntityDeathEvent::class]);
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(5);
		$this->setDescription("A chance to gain increased EXP when killing a mob.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("inquisitive", "inquisitive", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof EntityDeathEvent){
			if(ItemEditor::hasEnchantment($player->getInventory()->getItemInHand(), CustomEnchantHandler::getIdByClass(ApaceInquisitive::class))) return;
			$event->setXpDropAmount((int) ($event->getXpDropAmount() * (1 + (0.30 * $enchantInstance->getLevel()))));
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof EntityDeathEvent && $event->getEntity() instanceof Mob;
	}
}