<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class Luck extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(6);
		$this->setDescription("You're feeling lucky! Grinding wise enchantments will proc more often. This lucky is very weak, does not increase heroic enchantment proc rates.");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("luck", "Luck", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		//not implementing?
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return false;
	}
}