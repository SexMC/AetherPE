<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class Lifesteal extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(5);
		$this->setDescription("A chance to siphon HP from your target.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("lifesteal", "Lifesteal");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$event->getEntity()->setHealth($event->getEntity()->getHealth() - ($enchantInstance->getLevel() / 2));
			$player->setHealth($player->getHealth() + ($enchantInstance->getLevel() / 2));

			$this->setCooldown($player, 30);
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel() * 2 && !$this->isOnCooldown($player) && !$this->isOnCooldown($player);
	}
}