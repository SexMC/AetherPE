<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;


use pocketmine\block\BlockLegacyIds;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\Event;
use pocketmine\item\ItemIds;
use pocketmine\network\mcpe\protocol\ItemFrameDropItemPacket;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherPlayer;
use skyblock\sessions\Session;
use skyblock\utils\EntityUtils;

class XPDiscovery extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([BlockBreakEvent::class]);
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(5);
		$this->setDescription("Chance to mine up EXP from blocks.");
		$this->setApplicableTo(self::ITEM_PICKAXE);

		return new CustomEnchantIdentifier("xp_discovery", "XP Discovery");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof BlockBreakEvent && $player instanceof AetherPlayer) {
			$amount = mt_rand($enchantInstance->getLevel() * 250, $enchantInstance->getLevel() * 250 * 2);
			
			$player->getXpManager()->addXp($amount, true, false);
			$player->sendTip("§a+" . number_format($amount) . " XP");
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool{
		return $event instanceof BlockBreakEvent && mt_rand(1, 1500) <= $enchantInstance->getLevel();
	}
}