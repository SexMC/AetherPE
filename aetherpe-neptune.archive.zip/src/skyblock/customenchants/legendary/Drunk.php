<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\item\Item;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ToggleableEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\player\AetherEffect;
use skyblock\utils\CustomEnchantUtils;
use skyblock\utils\Utils;

class Drunk extends ToggleableEnchant {
	public function prepare() : CustomEnchantIdentifier{
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(4);
		$this->setDescription("Slowness and slow swinging with a chance to give buffed strength");
		$this->setApplicableTo(self::ITEM_HELMET);

		return new CustomEnchantIdentifier("drunk", "Drunk");
	}

	function toggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		$player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::STRENGTH(), 20 * 999999, $enchantmentInstance->getLevel() - 1)));
		$player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::MINING_FATIGUE(), 20 * 999999, $enchantmentInstance->getLevel() - 1)));
		$player->getEffects()->add(AetherEffect::fromPlayer($player, new EffectInstance(VanillaEffects::SLOWNESS(), 20 * 999999, $enchantmentInstance->getLevel() - 1)));
	}

	function unToggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		$player->getEffects()->remove(VanillaEffects::STRENGTH());
		$player->getEffects()->remove(VanillaEffects::SLOWNESS());
		$player->getEffects()->remove(VanillaEffects::MINING_FATIGUE());
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§e** Drunk (§r§7Received strength, you have to bless yourself with the custom enchant or command§l§e) **";
	}
}