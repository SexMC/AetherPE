<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\item\Item;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ToggleableEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\utils\CustomEnchantUtils;
use skyblock\utils\Utils;

class Overload extends ToggleableEnchant {
	public function prepare() : CustomEnchantIdentifier{
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(3);
		$this->setDescription("Increase Max Health based on level.");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("overload", "Overload", false);
	}

	function toggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		Utils::executeLater(function () use ($player): void {
			if($player->isOnline()){
				$player->setMaxHealth(CustomEnchantUtils::getMaxHealth($player));
			}
		}, 1);
	}

	function unToggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		Utils::executeLater(function () use ($player): void {
			if($player->isOnline()){
				$player->setMaxHealth(CustomEnchantUtils::getMaxHealth($player));
			}
		}, 1);
	}
}