<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\item\Item;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ToggleableEnchant;
use skyblock\items\ItemEditor;
use skyblock\items\rarity\Rarity;
use skyblock\traits\AwaitStdTrait;
use skyblock\utils\CustomEnchantUtils;
use skyblock\utils\Utils;
use SOFe\AwaitGenerator\Await;

class FullyBelly extends ToggleableEnchant {
	use AwaitStdTrait;

	public function prepare() : CustomEnchantIdentifier{
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(1);
		$this->setDescription("Don't lose hunger no more, you have a full belly!");
		$this->setApplicableTo(self::ITEM_CHESTPLATE);

		return new CustomEnchantIdentifier("fully_belly", "Fully Belly", false);
	}

	function toggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{
		Await::f2c(function() use($player) {
			while($player->isOnline()){
				if(ItemEditor::hasEnchantment($player->getArmorInventory()->getChestplate(), $this->getIdentifier()->getId())){
					$player->getHungerManager()->setSaturation(10);
					$player->getHungerManager()->setFood($player->getHungerManager()->getMaxFood());
					yield $this->getStd()->sleep(20);
				} else break;
			}
		});
	}

	function unToggle(Player $player, Item $item, CustomEnchantInstance $enchantmentInstance) : void{

	}
}