<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class DoubleStrike extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(3);
		$this->setDescription("Chance to strike your enemy twice.");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("double_strike", "Double Strike");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$event->multiplyDamage(2, "double_strike");
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel();
	}

	public function getActivateMessage(Player $player) : string{
		return "§r§l§b** Double Strike (§r§7You struck him twice§l§b) **";
	}
}