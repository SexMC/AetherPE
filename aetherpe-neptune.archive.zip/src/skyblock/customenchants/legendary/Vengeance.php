<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\event\Event;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\events\CustomEnchantsReactionManager;
use skyblock\events\CustomEntityDamageByEntityEvent;
use skyblock\islands\Island;
use skyblock\items\rarity\Rarity;
use skyblock\sessions\Session;

class Vengeance extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([CustomEntityDamageByEntityEvent::class]);
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(6);
		$this->setDescription("Deal more damage to PVE entities");
		$this->setApplicableTo(self::ITEM_SWORD);

		return new CustomEnchantIdentifier("vengeance", "Vengeance", false);
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof CustomEntityDamageByEntityEvent){
			$event->multiplyDamage(0.075 * $enchantInstance->getLevel(), "vengeance");
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof CustomEntityDamageByEntityEvent && $player->getId() === $event->getDamager()->getId() && !$event->getEntity() instanceof Player;
	}
}