<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;


use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\utils\EntityUtils;

class Clarity extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([EntityEffectAddEvent::class]);
		$this->setRarity(Rarity::rare());
		$this->setMaxLevel(3);
		$this->setDescription("A chance to block slowness and nausea");
		$this->setApplicableTo(self::ITEM_ARMOUR);

		return new CustomEnchantIdentifier("clarity", "Clarity");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof EntityEffectAddEvent){
			$event->cancel();
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool {
		return $event instanceof EntityEffectAddEvent && $player->getId() === $event->getEntity()->getId() && mt_rand(1, 100) <= $enchantInstance->getLevel() && ($event->getEffect()->getType()->getName() === VanillaEffects::BLINDNESS()->getName() || $event->getEffect()->getType()->getName() === VanillaEffects::NAUSEA()->getName());
	}
}