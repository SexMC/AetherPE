<?php

declare(strict_types=1);

namespace skyblock\customenchants\legendary;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Event;
use pocketmine\player\Player;
use skyblock\customenchants\CustomEnchantIdentifier;
use skyblock\customenchants\CustomEnchantInstance;
use skyblock\customenchants\ICustomEnchant;
use skyblock\customenchants\ReactiveEnchant;
use skyblock\items\rarity\Rarity;
use skyblock\items\special\types\EnchantmentDustPouch;
use skyblock\player\AetherPlayer;
use skyblock\utils\Utils;

class DustFinder extends ReactiveEnchant {

	public function prepare(): CustomEnchantIdentifier {
		$this->setEvents([BlockBreakEvent::class]);
		$this->setRarity(Rarity::legendary());
		$this->setMaxLevel(3);
		$this->setDescription("Chance to find a pouch of dust with rarity legendary or below");
		$this->setApplicableTo(self::ITEM_PICKAXE);

		return new CustomEnchantIdentifier("dust_finder", "Dust Finder");
	}

	public function Reaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): void {
		if($event instanceof BlockBreakEvent && $player instanceof AetherPlayer) {
			$tiers = [ICustomEnchant::RARITY_LEGENDARY, ICustomEnchant::RARITY_RARE, ICustomEnchant::RARITY_ELITE, ICustomEnchant::RARITY_UNCOMMON];
			$item = EnchantmentDustPouch::getItem($tiers[array_rand($tiers)]);
			Utils::addItem($player, $item);
		}
	}

	public function preReaction(Player $player, Event $event, CustomEnchantInstance $enchantInstance): bool{
		return $event instanceof BlockBreakEvent && mt_rand(1, 1500) <= $enchantInstance->getLevel();
	}
}