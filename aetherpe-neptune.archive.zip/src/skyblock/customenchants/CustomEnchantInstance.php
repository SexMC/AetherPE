<?php

declare(strict_types=1);

namespace skyblock\customenchants;

use pocketmine\item\Item;

class CustomEnchantInstance {

	public function __construct(private CustomEnchant $customEnchant, private Item $item, private int $level){ }

    public function getCustomEnchant() : CustomEnchant{
        return $this->customEnchant;
    }

    public function setCustomEnchant(CustomEnchant $customEnchant) : void{
        $this->customEnchant = $customEnchant;
    }

    public function getItem(): Item {
        return $this->item;
    }

    public function setItem(Item $item): void {
        $this->item = $item;
    }

	public function getLevel() : int{
		return $this->level;
	}

	public function setLevel(int $level) : void{
		$this->level = $level;
	}
}