<?php

namespace skyblock\customenchants;

final class CustomEnchantIdentifier {

    private string $id;
    private string $name;
    private string $important;

    public function __construct(string $id, string $name, bool $important = true) {
        $this->id = $id;
        $this->name = $name;
        $this->important = $important;
    }

    public function getId(): string {
        return $this->id;
    }

    public function getName(): string {
        return $this->name;
    }

    public function getFullName(): string {
        return $this->id . ":" . $this->name;
    }

    /**
     * @return bool
     * If called true the CustomEnchant will be "important" meaning it will show
     * an activate-message to the player when an Event is called such as equipping
     * an Item with the CustomEnchant on, or hitting another player with an Item
     * that has the CustomEnchant applied onto it.
     */
    public function isImportant(): bool {
        return $this->important;
    }

}