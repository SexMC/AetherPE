<?php

declare(strict_types=1);

namespace skyblock;

use pocketmine\block\BlockFactory;
use pocketmine\data\bedrock\EntityLegacyIds;
use pocketmine\data\bedrock\PotionTypeIdMap;
use pocketmine\data\bedrock\PotionTypeIds;
use pocketmine\data\SavedDataLoadingException;
use pocketmine\entity\Entity;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Location;
use pocketmine\entity\object\FallingBlock;
use pocketmine\entity\object\ItemEntity;
use pocketmine\entity\Skin;
use pocketmine\item\SpawnEgg;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Server;
use pocketmine\world\World;
use skyblock\entity\ai\MovingEntity;
use skyblock\entity\boss\ChickenBoss;
use skyblock\entity\boss\IslandBossEntity;
use skyblock\entity\boss\WitheredBlazeBoss;
use skyblock\entity\FishingRodEntity;
use skyblock\entity\LightningEntity;
use skyblock\entity\minion\types\MinerMinion;
use skyblock\entity\minion\types\SlayerMinion;
use skyblock\entity\misc\CarpenterFallingBlock;
use skyblock\entity\Mob;
use skyblock\entity\mob\BlazeEntity;
use skyblock\entity\mob\ChickenEntity;
use skyblock\entity\mob\CowEntity;
use skyblock\entity\mob\GhastEntity;
use skyblock\entity\mob\GuardianEntity;
use skyblock\entity\mob\IronGolemEntity;
use skyblock\entity\mob\MagmaCubeEntity;
use skyblock\entity\mob\MooshroomEntity;
use skyblock\entity\mob\PhantomEntity;
use skyblock\entity\mob\PigEntity;
use skyblock\entity\mob\SkeletonEntity;
use skyblock\entity\mob\SlimeEntity;
use skyblock\entity\mob\SquidEntity;
use skyblock\entity\mob\TurtleEntity;
use skyblock\entity\mob\WitherEntity;
use skyblock\entity\mob\ZombieEntity;
use skyblock\entity\mob\ZombiePigmanEntity;
use skyblock\entity\SplashPotion;
use skyblock\entity\TestEntity;
use skyblock\traits\AwaitStdTrait;
use skyblock\traits\InstanceTrait;
use skyblock\utils\Utils;
use SOFe\AwaitGenerator\Await;

class EntityHandler {

	use InstanceTrait;
	use AwaitStdTrait;

	private array $clearlagEntities = [
		ZombieEntity::class,
		WitherEntity::class,
		SquidEntity::class,
		SlimeEntity::class,
		SkeletonEntity::class,
		PigEntity::class,
		PhantomEntity::class,
		MooshroomEntity::class,
		IronGolemEntity::class,
		GhastEntity::class,
		CowEntity::class,
		BlazeEntity::class,
		ChickenEntity::class,
		GuardianEntity::class,
		MagmaCubeEntity::class,
		TurtleEntity::class,
		ZombiePigmanEntity::class,
	];

	private array $entities = [

	];

	private array $map;

	public function __construct(){
		self::$instance = $this;

        /** @var EntityFactory $factory */
		$factory = EntityFactory::getInstance();

		$factory->register(LightningEntity::class, function (World $world, CompoundTag $nbt): LightningEntity {
			return new LightningEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt);
		}, ["Lightning"]);

		$factory->register(MinerMinion::class, function(World $world, CompoundTag $nbt): MinerMinion {
			$tag = $nbt->getCompoundTag("Skin");

			$skin = new Skin(
				$tag->getString("Name"),
				$tag->getByteArray("Data"),
				$tag->getByteArray("CapeData"),
				$tag->getString("GeometryName"),
				$tag->getByteArray("GeometryData")
			);


			return new MinerMinion(EntityDataHelper::parseLocation($nbt, $world), $skin, $nbt);
		}, ["MinerMinionEntity"]);

		$factory->register(SlayerMinion::class, function(World $world, CompoundTag $nbt): SlayerMinion {
			$tag = $nbt->getCompoundTag("Skin");

			$skin = new Skin(
				$tag->getString("Name"),
				$tag->getByteArray("Data"),
				$tag->getByteArray("CapeData"),
				$tag->getString("GeometryName"),
				$tag->getByteArray("GeometryData")
			);


			return new SlayerMinion(EntityDataHelper::parseLocation($nbt, $world), $skin, $nbt);
		}, ["SlayerMinionEntity"]);

		$factory->register(FishingRodEntity::class, function (World $world, CompoundTag $nbt): FishingRodEntity {
			return new FishingRodEntity(EntityDataHelper::parseLocation($nbt, $world), null, $nbt);
		}, ["FishingRodEntity"]);

		$factory->register(IslandBossEntity::class, function (World $world, CompoundTag $nbt): IslandBossEntity {
			return new IslandBossEntity($nbt->getString("networkID38"), EntityDataHelper::parseLocation($nbt, $world), $nbt);
		}, ["FishingRodEntity"]);

		$factory->register(TestEntity::class, function (World $world, CompoundTag $nbt): TestEntity{
			return new TestEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt);
		}, ["TestEntity"]);

		$factory->register(WitheredBlazeBoss::class, function (World $world, CompoundTag $nbt): Entity{
			return new WitheredBlazeBoss(EntityDataHelper::parseLocation($nbt, $world), $nbt);
		}, ["wdfgdfgy"]);

		$factory->register(CarpenterFallingBlock::class, function (World $world, CompoundTag $nbt): CarpenterFallingBlock{
			return new CarpenterFallingBlock(EntityDataHelper::parseLocation($nbt, $world), FallingBlock::parseBlockNBT(BlockFactory::getInstance(), $nbt), $nbt);
		}, ["CarpenterFallingBlock"]);

        $factory->register(SplashPotion::class, function (World $world, CompoundTag $nbt): SplashPotion{
            $potionType = PotionTypeIdMap::getInstance()->fromId($nbt->getShort("PotionId", PotionTypeIds::WATER));
            if($potionType === null){
                throw new SavedDataLoadingException("No such potion type");
            }
            return new SplashPotion(EntityDataHelper::parseLocation($nbt, $world), null, $potionType, $nbt);
        }, ['ThrownPotion', 'minecraft:potion', 'thrownpotion'], EntityLegacyIds::SPLASH_POTION);

		foreach($this->clearlagEntities as $entity){
			$factory->register($entity, function(World $world, CompoundTag $nbt) use($entity): Entity {
				return new $entity(EntityDataHelper::parseLocation($nbt, $world), $nbt);
			}, [$entity::getNetworkTypeId()]);

			$this->clearlagEntities[$entity::getNetworkTypeId()] = $entity;
		}

		foreach($this->entities as $entity){
			$factory->register($entity, function(World $world, CompoundTag $nbt) use($entity): Entity {
				return new $entity(EntityDataHelper::parseLocation($nbt, $world), $nbt);
			}, [$entity::getNetworkTypeId()]);
		}
	}

	public function getEntity(string $identifier, Location $location, CompoundTag $nbt = null): ?Entity {
		if(isset($this->clearlagEntities[$identifier])){
			return new $this->clearlagEntities[$identifier]($location, $nbt);
		}

		return null;
	}

	public function clearlag(bool $force = false): void {
		Server::getInstance()->broadcastMessage(Main::PREFIX . "Starting clearlag on §c" . Utils::getServerName());

		if($force){
			$count = 0;

			foreach(Server::getInstance()->getWorldManager()->getWorlds() as $world){
				foreach($world->getEntities() as $entity){
					if($entity instanceof Mob || $entity instanceof ItemEntity){
						$entity->flagForDespawn();
						$count++;
					}
				}
			}

			Server::getInstance()->broadcastMessage(Main::PREFIX . "Cleared §c$count §7entities on §c" . Utils::getServerName());

			return;
		}


		Await::f2c(function() {
			$entities = [];

			foreach(Server::getInstance()->getWorldManager()->getWorlds() as $world){
				$entities = array_merge($entities, $world->getEntities());
			}

			$entities = array_values($entities);
			$count = 0;

			for($i = 0; $i < count($entities); $i++){
				if($i % 4 === 0 && $i !== 0){
					yield $this->getStd()->sleep(1);
				}

				$entity = $entities[$i] ?? null;
				if($entity instanceof Mob || $entity instanceof ItemEntity){
					if($entity->isClosed() || $entity->isFlaggedForDespawn()) continue;

					$count++;

					$entity->flagForDespawn();
				}
			}
			Server::getInstance()->broadcastMessage(Main::PREFIX . "Cleared §c$count §7entities on §c" . Utils::getServerName());
		});
	}
}